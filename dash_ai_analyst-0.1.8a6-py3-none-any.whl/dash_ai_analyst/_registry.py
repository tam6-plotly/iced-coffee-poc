"""Dataset registry for the chat plugin.

This module provides thread-safe storage for registered datasets that the AI
chat can access and query.

**Storage model:**

Registered datasets are persisted on disk in the shared data directory:

* **Tabular objects** (pandas, Polars, PyArrow, and GeoPandas
  GeoDataFrames) — written to
  ``<data_dir>/<scope>/<uuid>_<monotonic_ns>.duckdb`` at registration time
  via DuckDB replacement scans.  The original object can be
  garbage-collected immediately after registration.

* **External databases** (:class:`~._sources.Source`) — persisted as
  ``<data_dir>/<scope>/<uuid>_<monotonic_ns>.source.json`` recipe files
  containing the connection string, db_type, setup SQL, and cached table
  metadata.  At query time the recipe is replayed on a fresh per-request
  DuckDB connection: setup SQL is executed, then the source is ATTACHed.

At query time, :func:`~._tools._db.execute_query` creates a fresh
in-memory DuckDB connection, ATTACHes the relevant ``.duckdb`` files and
external sources for the current scope, creates plain-name VIEWs, and
executes the SQL.  Each request is independent — no shared connection,
no global lock.

Datasets can be registered globally (visible to all viewers) or scoped to a
specific user/session by passing ``user_scoped=True``.  Scoped entries win
on name collision when both exist.

**Cross-worker discovery:**

Workers that did not perform a registration discover it at query time by
scanning the per-scope subdirectories for ``.duckdb`` and
``.source.json`` files not yet in their in-memory cache.  This lazy-sync
mechanism means dynamic registrations (including user-scoped Sources
created inside callbacks) are visible to all workers sharing the
filesystem.

Unless ``DASH_AI_ANALYST_DATA_DIR`` is set, the default on-disk parent
directory is keyed by ``os.getcwd()`` and the process invocation
(``sys.argv``), so different ``python app.py`` / ``python other.py`` and
different ``gunicorn ... module:app`` runs from the same folder do not
reuse each other's persisted registrations.
"""

import hashlib
import json
import logging
import math
import os
import re
import sys
import tempfile
import threading
import time
import types
import uuid
from collections.abc import Mapping
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import duckdb
import flask
import pandas as pd
from typing_extensions import TypedDict

from ._secrets import apply_secrets, set_secret_resolver  # noqa: F401  (re-export)
from ._sources import Source

_logger = logging.getLogger(__name__)


class DataframeMetadata(TypedDict):
    """Metadata about a registered dataset."""

    name: str
    description: str
    columns: List[Dict[str, str]]  # [{name, dtype}]
    row_count: int
    sample_rows: List[Dict[str, Any]]  # First few rows as dicts
    connection_id: str  # Stable label for grouping datasets by source connection


class RegisteredDataset(TypedDict):
    """A registered data source entry.

    For DataFrames, ``duckdb_path`` points to the ``.duckdb`` file
    containing the data.  For external sources, ``source`` holds the
    :class:`~._sources.Source` descriptor and ``source_tables`` lists the
    ``(schema, table_name)`` pairs discovered at registration time.

    ``attach_alias`` is the DuckDB catalog alias used when ATTACHing an
    external source at query time (e.g. ``_daia_postgres_a1b2c3``).
    ``None`` for DataFrames.

    ``recipe_path`` points to the ``.source.json`` recipe file on disk
    (for Source entries).  ``None`` for tabular datasets.

    ``needs_spatial`` is True when the dataset was registered from a
    GeoPandas GeoDataFrame (or rediscovered with GEOMETRY columns) and
    requires the DuckDB ``spatial`` extension at query time.  ``False``
    for Source entries.
    """

    metadata: DataframeMetadata
    duckdb_path: Optional[str]
    source: Optional[Source]
    source_tables: Optional[List[Tuple[str, str]]]
    attach_alias: Optional[str]
    recipe_path: Optional[str]
    needs_spatial: bool


# ---------------------------------------------------------------------------
# Module-level storage directories
# ---------------------------------------------------------------------------

_GLOBAL_SCOPE_DIR = "__global__"


def _process_invocation_fingerprint() -> str:
    """Return a stable fingerprint source for the current process invocation.

    Uses ``sys.argv`` (with argv[0] absolutized when possible) so launcher
    flows like ``python app.py`` and ``gunicorn module:app`` naturally
    produce distinct keys without special-case logic.
    """
    if not sys.argv:
        return ""
    parts = list(sys.argv)
    try:
        parts[0] = os.path.abspath(parts[0])
    except (OSError, ValueError):
        pass
    return "\0".join(parts)


def _compute_data_dir() -> str:
    """Return a deterministic, shared dataset directory.

    All Gunicorn workers for the same app resolve to the same path so that
    ``.duckdb`` files written by one worker are visible to all others.

    Override with ``DASH_AI_ANALYST_DATA_DIR`` for custom placement.
    """
    configured = os.environ.get("DASH_AI_ANALYST_DATA_DIR")
    if configured:
        base = configured
    else:
        cwd = os.getcwd()
        invocation = _process_invocation_fingerprint()
        payload = cwd.encode("utf-8", errors="surrogateescape") + b"\0" + invocation.encode(
            "utf-8", errors="surrogateescape"
        )
        dir_key = hashlib.md5(payload).hexdigest()[:12]
        base = os.path.join(tempfile.gettempdir(), f"dash_ai_analyst_{dir_key}")
    data_dir = os.path.join(base, "datasets")
    os.makedirs(data_dir, exist_ok=True)
    return data_dir


_data_dir: str = _compute_data_dir()


def get_data_dir() -> str:
    """Return the path to the datasets directory."""
    return _data_dir


# ---------------------------------------------------------------------------
# Scope-aware path helpers
# ---------------------------------------------------------------------------


# A scope key becomes a directory name, so it is restricted to a charset with
# no path separators and no ``.``.  That makes traversal unrepresentable: an
# absolute path or a ``..`` segment would otherwise escape the data directory
# and expose any `.duckdb`/`.source.json` file on the host to the agent.
# `get_session_scope` mints UUID4s; the tests use ``__sentinel__`` names.
_SCOPE_RE = re.compile(r"\A[A-Za-z0-9_-]{1,128}\Z")


def _scope_path(scope: Optional[str]) -> str:
    """Return the directory path for *scope* without creating it.

    Raises:
        ValueError: If *scope* is not a well-formed scope key, or would
            resolve outside the data directory.
    """
    if scope is None:
        subdir = _GLOBAL_SCOPE_DIR
    elif isinstance(scope, str) and _SCOPE_RE.match(scope):
        subdir = scope
    else:
        raise ValueError(f"Invalid scope key: {scope!r}")

    path = os.path.join(_data_dir, subdir)
    # _SCOPE_RE already rules this out, but we should still assert directly
    # that the resulting path remains directly under `_data_dir`
    if os.path.dirname(os.path.normpath(path)) != os.path.normpath(_data_dir):
        raise ValueError(f"Scope key escapes the data directory: {scope!r}")
    return path


def _scope_dir(scope: Optional[str]) -> str:
    """Return the directory for *scope*, creating it if necessary."""
    d = _scope_path(scope)
    os.makedirs(d, exist_ok=True)
    return d


def _new_db_path(scope: Optional[str]) -> str:
    """Return a fresh ``.duckdb`` path with a UUID and monotonic timestamp.

    Filename format: ``<uuid_hex>_<monotonic_ns>.duckdb``.  The trailing
    timestamp lets :func:`_sync_from_disk` pick the newest file when two
    versions of the same dataset coexist on disk briefly.

    time.monotonic_ns() from Python 3.10 onwards should use the same clock across all workers.
    """
    return os.path.join(
        _scope_dir(scope),
        f"{uuid.uuid4().hex}_{time.monotonic_ns()}.duckdb",
    )


def _new_recipe_path(scope: Optional[str], registration_ts: Optional[int] = None) -> str:
    """Return a fresh ``.source.json`` path with a UUID and monotonic timestamp."""
    ts = registration_ts if registration_ts is not None else time.monotonic_ns()
    return os.path.join(
        _scope_dir(scope),
        f"{uuid.uuid4().hex}_{ts}.source.json",
    )


def _filename_timestamp(filename: str) -> int:
    """Extract the monotonic-ns timestamp from a persisted data filename, or 0."""
    stem = filename
    for suffix in (".duckdb", ".source.json"):
        if stem.endswith(suffix):
            stem = stem[: -len(suffix)]
            break
    parts = stem.rsplit("_", 1)
    if len(parts) == 2 and parts[1].isdigit():
        return int(parts[1])
    return 0


# ---------------------------------------------------------------------------
# Registry state
# ---------------------------------------------------------------------------

_registry_lock = threading.Lock()

# Outer key: scope (None = global, str = user/session-scoped).
# Inner key: dataset name.
_registry: Dict[Optional[str], Dict[str, RegisteredDataset]] = {}

# Auto-discovery state
_auto_discovery_lock = threading.Lock()
_auto_discovery_done = False

# Paths to .source.json files currently loaded into the in-memory registry.
# Kept in sync with registry entries so removals can discard stale paths.
_known_recipe_paths: set = set()
# Generated deployment wrapper modules that load the app entrypoint
# dynamically without registering it in sys.modules, keeping the module
# object in a global named "module".  Discovery reads it from there.
_WRAPPER_MODULES: Tuple[str, ...] = ("_plotly_wsgi", "_plotly_asgi")
_WRAPPER_ENTRYPOINT_ATTR = "module"


def _wrapper_entrypoints() -> List[Tuple[str, dict]]:
    """Return entrypoint namespaces held by known wrapper modules."""
    found: List[Tuple[str, dict]] = []
    for wrapper_name in _WRAPPER_MODULES:
        wrapper = sys.modules.get(wrapper_name)
        entrypoint = getattr(wrapper, _WRAPPER_ENTRYPOINT_ATTR, None)
        if isinstance(entrypoint, types.ModuleType):
            name = getattr(entrypoint, "__name__", "") or "<entrypoint>"
            found.append((name, vars(entrypoint)))
    return found


# Module roots to always skip during auto-discovery.
# (Most third-party roots are detected dynamically from sys.modules.)
_ALWAYS_SKIP_MODULE_ROOTS: frozenset[str] = frozenset({"dash_ai_analyst"})

# sys.stdlib_module_names is in Python 3.10+
_SKIP_MODULE_ROOTS: frozenset[str] = frozenset(sys.stdlib_module_names) | _ALWAYS_SKIP_MODULE_ROOTS  # pyright: ignore[reportAttributeAccessIssue]


def _collect_third_party_module_roots() -> set[str]:
    """Return top-level module roots loaded from site/dist-packages."""
    roots: set[str] = set()
    path_markers = {"site-packages", "dist-packages"}
    # .copy() is atomic under the GIL.  Iterating sys.modules directly races
    # with imports on other threads (the layout hook runs on a request thread
    # while the app may still be importing) and raises "dictionary changed
    # size during iteration".
    for mod_name, module in sys.modules.copy().items():
        if mod_name == "__main__" or module is None:
            continue
        module_file = getattr(module, "__file__", None)
        if not module_file:
            continue
        module_parts = {part.casefold() for part in Path(module_file).parts}
        if module_parts.intersection(path_markers):
            roots.add(mod_name.split(".")[0])
    return roots


def _discoverable_namespaces() -> List[Tuple[str, dict]]:
    """Return module namespaces eligible for auto-discovery scanning.

    Combines two sources, in priority order:

    1. The entrypoint module held by a known deployment wrapper module
       (see :func:`_wrapper_entrypoints`), which is loaded dynamically
       and never appears in ``sys.modules``.
    2. Loaded app modules from ``sys.modules`` (``__main__`` first, then
       alphabetical), excluding stdlib and third-party modules.

    Namespaces are deduplicated by identity, so an entrypoint reachable
    through both sources is scanned only once.
    """
    modules = list(sys.modules.items())
    modules.sort(key=lambda kv: (kv[0] != "__main__", kv[0]))
    third_party_roots = _collect_third_party_module_roots()

    namespaces: List[Tuple[str, dict]] = []
    seen_ns_ids: set = set()

    def _add(name: str, ns: dict) -> None:
        if id(ns) in seen_ns_ids:
            return
        seen_ns_ids.add(id(ns))
        namespaces.append((name, ns))

    for name, ns in _wrapper_entrypoints():
        _add(name, ns)

    for mod_name, module in modules:
        if module is None or not hasattr(module, "__dict__"):
            continue

        root = mod_name.split(".")[0]
        if mod_name != "__main__" and (
            root in _SKIP_MODULE_ROOTS
            or root in third_party_roots
        ):
            continue

        _add(mod_name, vars(module))

    return namespaces


def _is_registerable(obj: object) -> bool:
    """Return True if *obj* is a tabular type we can persist to a ``.duckdb`` file.

    Accepts only types that DuckDB can ingest directly via replacement
    scans: pandas DataFrames, Polars DataFrames, PyArrow Tables, and
    GeoPandas GeoDataFrames. Converts *obj* into native type before this
    check if it is a narwhals DataFrame.
    """
    try:
        import narwhals as nw

        if isinstance(obj, nw.DataFrame):
            obj = obj.to_native()
    except ImportError:
        pass

    try:
        import geopandas as gpd

        if isinstance(obj, gpd.GeoDataFrame):
            return True
    except ImportError:
        pass

    if isinstance(obj, pd.DataFrame):
        return True

    try:
        import polars as pl

        if isinstance(obj, pl.DataFrame):
            return True
    except ImportError:
        pass

    try:
        import pyarrow as pa

        if isinstance(obj, pa.Table):
            return True
    except ImportError:
        pass

    return False


def _needs_spatial(obj: object) -> bool:
    """Return True if *obj* requires the DuckDB ``spatial`` extension."""
    try:
        import geopandas as gpd

        return isinstance(obj, gpd.GeoDataFrame)
    except ImportError:
        return False


def get_session_scope() -> str:
    """Return a stable scope key for the current Flask request session.

    Generates a UUID on first call for the session and stores it in the Flask
    session cookie, so subsequent calls return the same key.  Must be called
    from within a Flask/Dash request context (e.g. inside a Dash callback).

    Returns:
        A UUID string uniquely identifying the current browser session.
    """
    if "_dash_ai_scope" not in flask.session:
        flask.session["_dash_ai_scope"] = str(uuid.uuid4())
    return flask.session["_dash_ai_scope"]


# ---------------------------------------------------------------------------
# Cross-worker disk discovery
# ---------------------------------------------------------------------------


def _extract_metadata_from_file(db_path: str) -> Optional["DataframeMetadata"]:
    """Open a ``.duckdb`` file and derive metadata from its contents.

    The file is expected to contain exactly one user table whose name is
    the dataset name.  The table's ``COMMENT`` (set at registration time)
    is used as the description.  Returns ``None`` on any failure.
    """
    try:
        conn = duckdb.connect(db_path, read_only=True)
    except Exception:
        _logger.exception("Failed to open %s for metadata extraction", db_path)
        return None
    try:
        rows = conn.execute("SELECT table_name, comment FROM duckdb_tables() WHERE schema_name = 'main'").fetchall()
        if not rows:
            return None
        table_name, comment = rows[0]

        col_types = conn.execute(
            "SELECT data_type FROM information_schema.columns "
            "WHERE table_name = ? AND table_schema = 'main'",
            [table_name],
        ).fetchall()
        if any(dt == "GEOMETRY" for (dt,) in col_types):
            conn.execute("LOAD spatial;")

        return _extract_metadata_from_conn(
            table_name,
            conn,
            table_name,
            description=comment or "",
            connection_id="__internal__",
        )
    except Exception:
        _logger.exception("Failed to extract metadata from %s", db_path)
        return None
    finally:
        conn.close()


def _sync_from_disk(scope: Optional[str]) -> None:
    """Synchronise this worker's in-memory registry with the on-disk state.

    Three operations:

    1. **Prune** — registry entries whose ``.duckdb`` file has been deleted
       (e.g. by another worker calling ``unregister_data``) are removed.
    2. **Add** — ``.duckdb`` files on disk with no registry entry are
       opened, metadata is extracted, and they are added to the registry.
    3. **Update** — when a new file on disk contains a dataset that is
       already registered under a *different* path (i.e. another worker
       re-registered the same name), the registry entry is updated to
       the new file and the old file is cleaned up.

    File paths already present in the registry are skipped to avoid
    expensive ``duckdb.connect()`` calls for files that haven't changed.
    """
    try:
        d = _scope_path(scope)
    except ValueError:
        _logger.warning("Refusing to sync datasets for invalid scope %r", scope)
        return
    if not os.path.isdir(d):
        return

    try:
        filenames = os.listdir(d)
    except OSError:
        _logger.exception("Failed to list scope directory %s", d)
        return

    disk_paths = {os.path.join(d, f) for f in filenames if f.endswith(".duckdb")}

    with _registry_lock:
        known_paths = {
            e["duckdb_path"]
            for e in _registry.get(scope, {}).values()
            if e.get("duckdb_path")
        }

    # --- Prune: evict entries whose files were deleted by another worker ---
    stale = known_paths - disk_paths
    if stale:
        with _registry_lock:
            scope_dict = _registry.get(scope, {})
            for name in list(scope_dict):
                entry = scope_dict[name]
                if entry.get("duckdb_path") and entry["duckdb_path"] in stale:
                    del scope_dict[name]

    # --- Add / Update ---
    old_files_to_remove: list[str] = []
    for db_path in disk_paths:
        if db_path in known_paths:
            continue

        metadata = _extract_metadata_from_file(db_path)
        if metadata is None:
            continue

        name = metadata["name"]
        new_ts = _filename_timestamp(os.path.basename(db_path))

        has_geometry = any(
            col.get("dtype") == "GEOMETRY" for col in metadata.get("columns", [])
        )

        with _registry_lock:
            if scope not in _registry:
                _registry[scope] = {}
            existing = _registry[scope].get(name)
            if existing is not None:
                if existing.get("duckdb_path") == db_path:
                    continue
                # Source entries (e.g. Postgres) are registered at module
                # level and have no .duckdb file — never displace them
                # with a discovered file that happens to share the name.
                if existing.get("source") is not None:
                    continue
                # Same dataset name at a different path: another worker
                # re-registered it.  During the brief overlap window both
                # the old and new UUID files may coexist on disk, so
                # compare the embedded monotonic timestamps to keep the
                # newer version and queue the older one for cleanup.
                existing_path = existing["duckdb_path"]
                if existing_path is not None:
                    existing_ts = _filename_timestamp(
                        os.path.basename(existing_path)
                    )
                    if new_ts <= existing_ts:
                        old_files_to_remove.append(db_path)
                        continue
                    old_files_to_remove.append(existing_path)
            _registry[scope][name] = RegisteredDataset(
                metadata=metadata,
                duckdb_path=db_path,
                source=None,
                source_tables=None,
                attach_alias=None,
                recipe_path=None,
                needs_spatial=has_geometry,
            )

    for old_path in old_files_to_remove:
        _remove_files(old_path)


# ---------------------------------------------------------------------------
# ATTACH helpers (used at registration time for metadata extraction)
# ---------------------------------------------------------------------------


_EXTENSION_FOR_TYPE: Dict[str, str] = {
    "postgres": "postgres",
    "mysql": "mysql",
}


def _ensure_extension(conn: duckdb.DuckDBPyConnection, db_type: str) -> None:
    """Install and load the DuckDB extension needed for *db_type* (if any)."""
    ext = _EXTENSION_FOR_TYPE.get(db_type)
    if ext:
        conn.execute(f"INSTALL {ext}; LOAD {ext};")


def _make_alias(connection_string: str, db_type: str) -> str:
    """Return a stable, DuckDB-safe catalog alias for a connection string."""
    h = hashlib.md5(f"{db_type}:{connection_string}".encode()).hexdigest()[:12]
    safe_type = re.sub(r"[^a-z0-9]", "_", db_type.lower())
    return f"_daia_{safe_type}_{h}"


def _list_attached_tables(
    conn: duckdb.DuckDBPyConnection,
    alias: str,
) -> List[Tuple[str, str]]:
    """Return ``(schema, table_name)`` pairs from an attached database."""
    rows = conn.execute(
        """
        SELECT schema_name, table_name
        FROM duckdb_tables()
        WHERE database_name = ?
          AND schema_name NOT IN (
              'information_schema', 'pg_catalog', 'pg_toast',
              'performance_schema', 'mysql', 'sys'
          )
        ORDER BY table_name
    """,
        [alias],
    ).fetchall()
    return [(row[0], row[1]) for row in rows]


def _resolve_table_schemas(
    conn: duckdb.DuckDBPyConnection,
    alias: str,
    tables: List[str],
) -> List[Tuple[str, str]]:
    """Return ``(schema, table_name)`` pairs for the given table names."""
    all_pairs = _list_attached_tables(conn, alias)
    table_to_schema = {t: s for s, t in all_pairs}
    result = []
    for t in tables:
        if t not in table_to_schema:
            available = sorted(table_to_schema)
            raise ValueError(f"Table {t!r} not found in attached database. Available tables: {available!r}")
        result.append((table_to_schema[t], t))
    return result


# ---------------------------------------------------------------------------
# Metadata extraction
# ---------------------------------------------------------------------------


def _json_safe_value(val: Any) -> Any:
    """Convert a single cell value to a JSON-safe Python scalar.

    Returns ``None`` for missing values *and* non-finite floats (``NaN``,
    ``+Inf``, ``-Inf``), which are not valid JSON per RFC 8259.  Without
    this, ``json.dumps``/``flask.jsonify`` emit bare ``NaN``/``Infinity``
    tokens that ``JSON.parse`` rejects in the browser.
    """
    if pd.isna(val):
        return None
    if isinstance(val, (bytes, bytearray)):
        return val.hex()
    if hasattr(val, "item"):  # numpy scalar → Python scalar
        val = val.item()
    if isinstance(val, float) and not math.isfinite(val):
        return None
    if hasattr(val, "isoformat"):  # datetime / date
        return val.isoformat()
    return val


def _extract_metadata_from_conn(
    name: str,
    conn: Any,
    table_name: str,
    description: str,
    connection_id: str = "__internal__",
    sample_size: int = 5,
) -> DataframeMetadata:
    """Extract metadata for a table or view inside an open DuckDB connection.

    Args:
        name: The registered name for this entry (used as the display name).
        conn: An open DuckDB connection containing the table or view.
        table_name: Actual table/view name inside the DuckDB connection.
        description: Human-readable description.
        connection_id: Stable label identifying the source connection.
        sample_size: Number of sample rows to include.
    """
    # Restrict to the connection's default catalog.  External sources are
    # ATTACHed under their own catalog but reuse the 'main' schema name
    # (always 'main' for SQLite/DuckDB files), so without the catalog filter
    # the base table and our same-named VIEW would both match and every
    # column would appear twice.
    col_rows = conn.execute(
        "SELECT column_name, data_type "
        "FROM information_schema.columns "
        "WHERE table_name = ? AND table_schema = 'main' "
        "AND table_catalog = current_database() "
        "ORDER BY ordinal_position",
        [table_name],
    ).fetchall()
    columns = [{"name": col, "dtype": dtype} for col, dtype in col_rows]

    row_count: int = conn.execute(f'SELECT COUNT(*) FROM "{table_name}"').fetchone()[0]

    geom_dtypes = {col for col, dtype in col_rows if dtype == "GEOMETRY"}
    if geom_dtypes:
        select_cols = ", ".join(
            f'ST_AsText("{col}") AS "{col}"' if col in geom_dtypes else f'"{col}"' for col, _ in col_rows
        )
        sample_df = conn.execute(f'SELECT {select_cols} FROM "{table_name}" LIMIT {sample_size}').df()
    else:
        sample_df = conn.execute(f'SELECT * FROM "{table_name}" LIMIT {sample_size}').df()
    sample_rows = []
    for _, row in sample_df.iterrows():
        row_dict: Dict[str, Any] = {}
        for col in sample_df.columns:
            row_dict[col] = _json_safe_value(row[col])
        sample_rows.append(row_dict)

    return DataframeMetadata(
        name=name,
        description=description,
        columns=columns,
        row_count=row_count,
        sample_rows=sample_rows,
        connection_id=connection_id,
    )


# ---------------------------------------------------------------------------
# Source recipe persistence
# ---------------------------------------------------------------------------


def _write_source_recipe(
    filepath: str,
    scope: Optional[str],
    source: Source,
    alias: str,
    name: str,
    db_schema: str,
    table_name: str,
    metadata: DataframeMetadata,
) -> None:
    """Atomically write a source recipe JSON file to disk."""
    recipe = {
        "scope": scope,
        "connection_string": source.connection_string,
        "db_type": source.db_type,
        "setup": list(source.setup),
        "attach_alias": alias,
        "name": name,
        "db_schema": db_schema,
        "table_name": table_name,
        "metadata": dict(metadata),
    }
    tmp_path = filepath + ".tmp"
    with open(tmp_path, "w") as f:
        json.dump(recipe, f)
    os.replace(tmp_path, filepath)


def _recipe_entry_from_file(
    filepath: str,
) -> Optional[Tuple[Optional[str], str, RegisteredDataset]]:
    """Read a ``.source.json`` file and build the matching registry entry."""
    try:
        with open(filepath) as f:
            recipe = json.load(f)
    except (OSError, json.JSONDecodeError):
        return None

    try:
        scope: Optional[str] = recipe.get("scope")
        name: str = recipe["name"]

        source = Source(
            connection_string=recipe["connection_string"],
            db_type=recipe["db_type"],
            setup=tuple(recipe.get("setup", ())),
        )
        alias: str = recipe["attach_alias"]
        db_schema: str = recipe["db_schema"]
        table_name: str = recipe["table_name"]
        metadata: DataframeMetadata = recipe["metadata"]
    except (KeyError, TypeError):
        return None

    return (
        scope,
        name,
        RegisteredDataset(
            metadata=metadata,
            duckdb_path=None,
            source=source,
            source_tables=[(db_schema, table_name)],
            attach_alias=alias,
            recipe_path=filepath,
            needs_spatial=False,
        ),
    )


def _remove_recipe_file(filepath: str) -> None:
    """Delete a ``.source.json`` recipe file."""
    try:
        os.remove(filepath)
    except FileNotFoundError:
        # Removed by another worker.
        pass
    except OSError:
        _logger.exception("Failed to remove %s", filepath)
    finally:
        _known_recipe_paths.discard(filepath)


def _sync_recipes_from_disk(scope: Optional[str] = None) -> None:
    """Synchronise Source recipe files for one scope with the in-memory registry.

    Mirrors :func:`_sync_from_disk` for ``.source.json`` files: stale
    entries are pruned, unknown recipes are loaded, and newer recipes
    replace older entries with the same table name.
    """
    try:
        d = _scope_path(scope)
    except ValueError:
        _logger.warning("Refusing to sync datasets for invalid scope %r", scope)
        return
    if not os.path.isdir(d):
        return

    try:
        filenames = os.listdir(d)
    except OSError:
        _logger.exception("Failed to list scope directory %s", d)
        return

    disk_paths = {os.path.join(d, f) for f in filenames if f.endswith(".source.json")}

    with _registry_lock:
        known_paths = {
            e["recipe_path"]
            for e in _registry.get(scope, {}).values()
            if e.get("recipe_path")
        }

    # --- Prune: evict Source entries whose recipe file was deleted ---
    stale = known_paths - disk_paths
    if stale:
        with _registry_lock:
            scope_dict = _registry.get(scope, {})
            for name in list(scope_dict):
                entry = scope_dict[name]
                recipe_path = entry.get("recipe_path")
                if recipe_path and recipe_path in stale:
                    del scope_dict[name]
                    _known_recipe_paths.discard(recipe_path)

    # --- Add / Update ---
    old_files_to_remove: list[str] = []
    for recipe_path in disk_paths:
        if recipe_path in known_paths:
            continue

        loaded = _recipe_entry_from_file(recipe_path)
        if loaded is None:
            continue
        recipe_scope, name, entry = loaded
        if recipe_scope != scope:
            continue

        new_ts = _filename_timestamp(os.path.basename(recipe_path))

        with _registry_lock:
            if scope not in _registry:
                _registry[scope] = {}
            existing = _registry[scope].get(name)
            if existing is not None:
                if existing.get("recipe_path") == recipe_path:
                    continue
                if existing.get("source") is None:
                    db_path = existing.get("duckdb_path")
                    if db_path and os.path.exists(db_path):
                        continue
                    del _registry[scope][name]
                else:
                    existing_path = existing.get("recipe_path")
                    if existing_path is not None:
                        existing_ts = _filename_timestamp(
                            os.path.basename(existing_path)
                        )
                        if new_ts <= existing_ts:
                            old_files_to_remove.append(recipe_path)
                            continue
                        old_files_to_remove.append(existing_path)
            _registry[scope][name] = entry
            _known_recipe_paths.add(recipe_path)

    for old_path in old_files_to_remove:
        _remove_recipe_file(old_path)


# ---------------------------------------------------------------------------
# Public registration API
# ---------------------------------------------------------------------------


def register_data(
    source: Any,
    name: Optional[str] = None,
    description: str = "",
    user_scoped: bool = False,
    tables: Optional[List[str]] = None,
) -> None:
    """Register data for the AI chat to access.

    Accepts a pandas DataFrame, Polars DataFrame, PyArrow Table, GeoPandas
    GeoDataFrame (or a Narwhals DataFrame wrapping these), or a
    :class:`~._sources.Source`.

    **Tabular objects** — pandas DataFrames, Polars DataFrames, PyArrow
    Tables, and GeoPandas GeoDataFrames — are immediately written to an
    individual DuckDB file on disk.  The plugin owns the copy; you can
    safely modify or discard the original object after calling this
    function.

    **Source** databases are persisted as recipe files on disk and
    ATTACHed to a fresh per-request DuckDB connection at query time.
    Sources can be registered at module level (global) or inside
    callbacks with ``user_scoped=True``.  The ``setup`` field on
    :class:`~._sources.Source` lets you specify prerequisite SQL
    (``INSTALL``, ``LOAD``, ``CREATE SECRET``, etc.) that is replayed
    before each ATTACH.

    Args:
        source: A pandas DataFrame, Polars DataFrame, PyArrow Table,
            GeoPandas GeoDataFrame (or a Narwhals DataFrame wrapping these), or a :class:`~._sources.Source`.
        name: Required when *source* is a tabular object; used as the
            dataset name.  Ignored for :class:`~._sources.Source` —
            table names come from the database.
        description: Human-readable description of the data.
        user_scoped: When ``True``, register data in the current viewer's
            private session scope (visible only to that browser session).
            Must be called from within a Dash callback or Flask request
            context.  Default ``False`` = global (visible to all viewers).
            Supported for both tabular objects and :class:`~._sources.Source`.
        tables: :class:`~._sources.Source` only.  Table names to
            register.  ``None`` registers every table found in the source
            database (excluding system schemas).

    Examples::

        # pandas DataFrame
        register_data(sales_df, "sales", "Monthly sales by region")

        # Polars DataFrame
        register_data(polars_df, "products", "Product catalog")

        # PyArrow Table
        register_data(arrow_table, "events", "Click events")

        # GeoPandas GeoDataFrame
        register_data(gdf, "counties", "US county boundaries")

        # Per-viewer DataFrame inside a Dash callback
        register_data(df, "orders", user_scoped=True)

        # DuckDB file — metadata extracted; original file is never modified
        register_data(Source("analytics.duckdb"))
        register_data(Source("analytics.duckdb"), tables=["orders"])

        # PostgreSQL with explicit extension setup
        register_data(
            Source(
                "host=localhost dbname=mydb",
                db_type="postgres",
                setup=("INSTALL postgres", "LOAD postgres"),
            ),
            tables=["orders", "customers"],
        )

        # User-scoped Source inside a Dash callback
        register_data(
            Source(
                "host=db.example.com dbname=analytics user=viewer_42",
                db_type="postgres",
                setup=("INSTALL postgres", "LOAD postgres"),
            ),
            tables=["orders"],
            user_scoped=True,
        )
    """

    scope = get_session_scope() if user_scoped else None

    if isinstance(source, Source):
        _register_source(source, tables, description, scope)
    elif _is_registerable(source):
        if not name:
            raise ValueError("name is required when registering a tabular object")
        spatial = _needs_spatial(source)
        _register_df(name, source, description, scope, needs_spatial=spatial)
    else:
        raise TypeError(
            f"source must be a pandas DataFrame, Polars DataFrame, "
            f"PyArrow Table, GeoPandas GeoDataFrame (or a Narwhals DataFrame wrapping these), "
            f"or Source - got {type(source).__name__!r}"
        )


def _register_df(
    name: str,
    df: Any,
    description: str,
    scope: Optional[str],
    needs_spatial: bool = False,
    if_absent: bool = False,
) -> bool:
    """Write a tabular object to a ``.duckdb`` file and record in the registry.

    Uses DuckDB replacement scans so that pandas DataFrames, Polars
    DataFrames, PyArrow Tables, and GeoPandas GeoDataFrames can all be
    ingested without explicit conversion.

    When *if_absent* is ``True`` the registration is conditional: *name*
    must be free both when the write starts and when the registry entry
    is inserted, so a concurrent explicit ``register_data()`` for the
    same name is never overwritten.  Used by auto-discovery.

    Returns ``True`` when *name* ends up registered by this call, and
    ``False`` when the write failed or a conditional registration lost
    the name to a concurrent registration.
    """
    with _registry_lock:
        scoped = _registry.get(scope, {})
        if if_absent and name in scoped:
            return False
        old = scoped.pop(name, None)
    old_db_path = old["duckdb_path"] if old is not None else None

    db_path = _new_db_path(scope)
    tmp_path = db_path + f".{os.getpid()}.tmp"

    conn = duckdb.connect(tmp_path)
    try:
        geom_cols: List[str] = []
        if needs_spatial:
            conn.execute("INSTALL spatial; LOAD spatial;")
            try:
                import geopandas as _gpd

                if isinstance(df, _gpd.GeoDataFrame):
                    geom_cols = [c for c in df.columns if df[c].dtype.name == "geometry"]
                    df = df.to_wkb()
            except ImportError:
                _logger.warning("GeoPandas not found, skipping spatial support")

        # DuckDB replacement scan: ``__source__`` is resolved from this
        # frame's local variables and supports pandas, Polars, Arrow, and
        # GeoPandas objects natively.
        __source__ = df  # noqa: F841 — used by DuckDB replacement scan
        conn.execute(f'CREATE TABLE "{name}" AS SELECT * FROM __source__')
        for col in geom_cols:
            conn.execute(f'ALTER TABLE "{name}" ALTER COLUMN "{col}" TYPE GEOMETRY USING ST_GeomFromWKB("{col}")')
        escaped = description.replace("'", "''")
        conn.execute(f"""COMMENT ON TABLE "{name}" IS '{escaped}'""")
        metadata = _extract_metadata_from_conn(
            name,
            conn,
            name,
            description,
            connection_id="__internal__",
        )
    except Exception:
        _logger.exception("Failed to register DataFrame %s", name)
        os.remove(tmp_path)
        return False
    finally:
        conn.close()

    with _registry_lock:
        if scope not in _registry:
            _registry[scope] = {}
        if if_absent and name in _registry[scope]:
            # A concurrent registration claimed the name while we were
            # writing.  Leave theirs alone and drop our copy.
            lost_race = True
        else:
            lost_race = False
            # Publish the file and the registry entry together, so a
            # registration that loses the race never leaves a stray
            # ``.duckdb`` file for other workers to discover.
            os.replace(tmp_path, db_path)
            _registry[scope][name] = RegisteredDataset(
                metadata=metadata,
                duckdb_path=db_path,
                source=None,
                source_tables=None,
                attach_alias=None,
                recipe_path=None,
                needs_spatial=needs_spatial,
            )

    if lost_race:
        _remove_files(tmp_path)
        return False

    if old_db_path is not None:
        _remove_files(old_db_path)

    return True


def _register_source(
    source: Source,
    tables: Optional[List[str]],
    description: str,
    scope: Optional[str],
) -> None:
    """Persist *source* as recipe files and record in the registry.

    Uses an ephemeral DuckDB connection to execute setup SQL, ATTACH the
    source, discover tables, and extract metadata.  For each table a
    ``.source.json`` recipe file is written so other workers can replay
    the ATTACH at query time.
    """
    alias = _make_alias(source.connection_string, source.db_type)
    registration_ts = time.monotonic_ns()

    conn = duckdb.connect()
    try:
        for stmt in source.setup:
            conn.execute(apply_secrets(stmt, scope))

        _ensure_extension(conn, source.db_type)
        type_clause = f", TYPE {source.db_type}" if source.db_type != "duckdb" else ""
        resolved_conn_str = apply_secrets(source.connection_string, scope)
        attach_sql = (
            f"ATTACH '{resolved_conn_str}' "
            f'AS "{alias}" (READ_ONLY{type_clause})'
        )
        conn.execute(attach_sql)

        _logger.debug("Listing tables for alias %r", alias)
        if tables is None:
            schema_table_pairs = _list_attached_tables(conn, alias)
        else:
            schema_table_pairs = _resolve_table_schemas(conn, alias, tables)
        _logger.debug("Discovered tables: %s", schema_table_pairs)

        for db_schema, table_name in schema_table_pairs:
            _remove_entry(scope, table_name)

            conn.execute(
                f'CREATE VIEW main."{table_name}" AS '
                f'SELECT * FROM "{alias}"."{db_schema}"."{table_name}"'
            )
            metadata = _extract_metadata_from_conn(
                table_name,
                conn,
                table_name,
                description,
                connection_id=alias,
            )

            recipe_path = _new_recipe_path(scope, registration_ts)
            _write_source_recipe(
                recipe_path,
                scope,
                source,
                alias,
                table_name,
                db_schema,
                table_name,
                metadata,
            )
            _known_recipe_paths.add(recipe_path)

            with _registry_lock:
                if scope not in _registry:
                    _registry[scope] = {}
                _registry[scope][table_name] = RegisteredDataset(
                    metadata=metadata,
                    duckdb_path=None,
                    source=source,
                    source_tables=[(db_schema, table_name)],
                    attach_alias=alias,
                    recipe_path=recipe_path,
                    needs_spatial=False,
                )
    finally:
        conn.close()


def _remove_files(db_path: str) -> None:
    """Delete a ``.duckdb`` file."""
    try:
        os.remove(db_path)
    except FileNotFoundError:
        # Removed by another worker.
        pass
    except OSError:
        _logger.exception("Failed to remove %s", db_path)


def _remove_entry(scope: Optional[str], name: str) -> None:
    """Remove a registry entry and delete its backing file(s) if applicable."""
    with _registry_lock:
        old = _registry.get(scope, {}).pop(name, None)
    if old is None:
        return
    for path_key in ("duckdb_path", "recipe_path"):
        path = old.get(path_key)
        if not path:
            continue
        if path_key == "duckdb_path":
            _remove_files(path)
        else:
            _remove_recipe_file(path)


def unregister_data(name: str, user_scoped: bool = False) -> bool:
    """Remove a dataset from the registry.

    Args:
        name: Name of the dataset to remove.
        user_scoped: When ``True``, remove from the current viewer's private
            session scope.  Must be called from within a Dash callback or
            Flask request context.  Default ``False`` removes from the global
            scope.

    Returns:
        True if the dataset was removed, False if it wasn't registered.
    """
    scope = get_session_scope() if user_scoped else None
    with _registry_lock:
        old = _registry.get(scope, {}).pop(name, None)
    if old is None:
        return False
    for path_key in ("duckdb_path", "recipe_path"):
        path = old.get(path_key)
        if not path:
            continue
        if path_key == "duckdb_path":
            _remove_files(path)
        else:
            _remove_recipe_file(path)
    return True


def _get_registered_data_for_scope(scope: Optional[str]) -> Dict[str, RegisteredDataset]:
    """Internal: look up datasets by an explicit scope string.

    Syncs recipe files and ``.duckdb`` files from disk so registrations
    made by other workers are visible.  Used by query execution code that
    already holds a resolved scope key.  Public callers should use
    :func:`get_registered_data`.
    """
    _sync_recipes_from_disk(None)
    _sync_from_disk(None)
    if scope is not None:
        _sync_recipes_from_disk(scope)
        _sync_from_disk(scope)
    with _registry_lock:
        global_entries = dict(_registry.get(None, {}))
        if scope is not None:
            scoped_entries = dict(_registry.get(scope, {}))
            return {**global_entries, **scoped_entries}
        return global_entries


def get_registered_data(user_scoped: bool = False) -> Dict[str, RegisteredDataset]:
    """Get registered datasets, merging globals with any scoped entries.

    Args:
        user_scoped: When ``True``, merge global datasets with the current
            viewer's private session datasets (scoped wins on name
            collision).  Must be called from within a Dash callback or
            Flask request context.  Default ``False`` returns global datasets only.

    Returns:
        Dictionary mapping names to registered datasets.
    """
    scope = get_session_scope() if user_scoped else None
    return _get_registered_data_for_scope(scope)


def get_data_metadata(name: str, scope: Optional[str] = None) -> Optional[DataframeMetadata]:
    """Get metadata for a specific dataset.

    Checks the given *scope* first (if provided), then falls back to the
    global scope.

    Args:
        name: Name of the dataset.
        scope: Optional scope key to search first.

    Returns:
        The metadata if found, None otherwise.
    """
    _sync_recipes_from_disk(None)
    _sync_from_disk(None)
    if scope is not None:
        _sync_recipes_from_disk(scope)
        _sync_from_disk(scope)
    with _registry_lock:
        if scope is not None:
            scoped = _registry.get(scope, {})
            if name in scoped:
                return scoped[name]["metadata"]
        global_dict = _registry.get(None, {})
        if name in global_dict:
            return global_dict[name]["metadata"]
        return None


def get_all_metadata(scope: Optional[str] = None) -> List[DataframeMetadata]:
    """Get metadata for all relevant dataframes.

    Returns global metadata merged with any scope-specific metadata.  Scoped
    entries win on name collision with globals.

    Args:
        scope: Optional scope key.  When provided, its datasets are merged on
            top of global datasets.

    Returns:
        List of metadata for each dataframe visible in this scope.
    """
    _sync_recipes_from_disk(None)
    _sync_from_disk(None)
    if scope is not None:
        _sync_recipes_from_disk(scope)
        _sync_from_disk(scope)
    with _registry_lock:
        global_entries = _registry.get(None, {})
        if scope is not None:
            scoped_entries = _registry.get(scope, {})
            merged = {**global_entries, **scoped_entries}
            return [entry["metadata"] for entry in merged.values()]
        return [entry["metadata"] for entry in global_entries.values()]


def clear_data(user_scoped: bool = False) -> None:
    """Remove registered datasets.

    Args:
        user_scoped: When ``True``, remove only the current viewer's private
            session datasets.  Must be called from within a Dash callback or
            Flask request context.  Default ``False`` removes *all* datasets
            in all scopes.
    """
    scope = get_session_scope() if user_scoped else None

    with _registry_lock:
        if scope is not None:
            to_clean = list(_registry.pop(scope, {}).values())
        else:
            to_clean = [e for d in _registry.values() for e in d.values()]
            _registry.clear()

    for entry in to_clean:
        for path_key in ("duckdb_path", "recipe_path"):
            path = entry.get(path_key)
            if not path:
                continue
            if path_key == "duckdb_path":
                _remove_files(path)
            else:
                _remove_recipe_file(path)


def _auto_register(name: str, obj: Any, ns_name: str) -> bool:
    """Register an auto-discovered tabular object in the global scope.

    Registration is conditional on *name* still being free, so an
    explicitly registered dataset is never overwritten even if it lands
    while this call is in flight.  Returns ``True`` only when the name
    ends up in the registry as a result of this call.

    The registry is synced from the shared data directory first, so a
    name another worker has already persisted — including one it
    registered explicitly — is seen and left alone rather than being
    displaced by a newer auto-discovered file.
    """
    _sync_recipes_from_disk(None)
    _sync_from_disk(None)
    with _registry_lock:
        if name in _registry.get(None, {}):
            return False

    try:
        registered = _register_df(
            name,
            obj,
            "",
            None,
            needs_spatial=_needs_spatial(obj),
            if_absent=True,
        )
    except Exception:
        _logger.warning(
            "Auto-discovery: failed to register %r from module %r",
            name,
            ns_name,
            exc_info=True,
        )
        return False
    if not registered:
        _logger.warning(
            "Auto-discovery: %r from module %r was not registered "
            "(write failed, or the name was taken by another registration)",
            name,
            ns_name,
        )
    return registered


def _unwrap_get_data_result(result: object, ns_name: str) -> List[Tuple[str, Any]]:
    """Expand a ``get_data()`` return value into ``(name, object)`` pairs.

    Three shapes are accepted:

    * a single tabular object — named ``"data"``;
    * a mapping of name -> tabular object — each key used as the dataset
      name;
    * a list or tuple of tabular objects — named ``data_1``,
      ``data_2``, ...

    Anything else is skipped with a warning, so an app whose ``get_data()``
    returns an unsupported shape leaves a trace in the logs rather than
    silently showing zero datasets.
    """
    if _is_registerable(result):
        return [("data", result)]

    pairs: List[Tuple[str, Any]] = []

    if isinstance(result, Mapping):
        for key, value in result.items():
            if not isinstance(key, str) or not key.strip() or '"' in key:
                _logger.warning(
                    "Auto-discovery: skipping get_data() entry with unusable name %r from module %r",
                    key,
                    ns_name,
                )
                continue
            if not _is_registerable(value):
                _logger.warning(
                    "Auto-discovery: skipping get_data() entry %r from module %r - %s is not a supported tabular type",
                    key,
                    ns_name,
                    type(value).__name__,
                )
                continue
            pairs.append((key.strip(), value))
        return pairs

    if isinstance(result, (list, tuple)):
        for index, value in enumerate(result, start=1):
            if not _is_registerable(value):
                _logger.warning(
                    "Auto-discovery: skipping get_data() item %d from module %r - %s is not a supported tabular type",
                    index,
                    ns_name,
                    type(value).__name__,
                )
                continue
            pairs.append((f"data_{index}", value))
        return pairs

    _logger.warning(
        "Auto-discovery: ignoring get_data() from module %r - it returned %s, "
        "which is not a tabular object, a list of them, or a name -> object "
        "mapping",
        ns_name,
        type(result).__name__,
    )
    return []


def auto_discover_data() -> None:
    """Discover and register tabular objects from loaded app modules.

    Scans all non-framework module namespaces (see
    :func:`_discoverable_namespaces` — ``sys.modules`` entries plus the
    entrypoint module held by a known deployment wrapper) for two kinds
    of data sources:

    1. **Global tabular variables** — pandas DataFrames, Polars DataFrames,
       PyArrow Tables, and GeoPandas GeoDataFrames (or a Narwhals DataFrame
       wrapping these) — registered under their variable name.

    2. A **``get_data()`` function** — if present, it is called and its
       return value registered.  This covers auto-generated apps that load
       data via a cached ``get_data()`` function rather than module-level
       variables.  Three return shapes are supported: a single tabular
       object (registered as ``"data"``), a mapping of name -> tabular
       object (each key used as the dataset name), or a list/tuple of
       tabular objects (named ``data_1``, ``data_2``, ...).  Any other return
       value is ignored with a warning.  The function must be callable
       with no arguments; scanning stops at the first module whose
       ``get_data()`` registers at least one dataset.

    Only runs once per process; manually registered datasets take
    precedence and are never overwritten.

    Auto-discovered data is always registered in the global scope
    (``scope=None``) so it is visible to all viewers.
    """
    global _auto_discovery_done
    with _auto_discovery_lock:
        if _auto_discovery_done:
            return
        _auto_discovery_done = True

    # Pick up datasets other workers have already persisted to the shared
    # data directory so their names are treated as taken.
    _sync_recipes_from_disk(None)
    _sync_from_disk(None)
    with _registry_lock:
        existing = set(_registry.get(None, {}).keys())

    seen_obj_ids: set = set()

    for ns_name, namespace in _discoverable_namespaces():
        for var_name, obj in list(namespace.items()):
            if var_name.startswith("_"):
                continue
            if not _is_registerable(obj):
                continue
            obj_id = id(obj)
            if obj_id in seen_obj_ids:
                continue
            if var_name in existing:
                continue
            seen_obj_ids.add(obj_id)
            existing.add(var_name)
            _auto_register(var_name, obj, ns_name)

    # Second pass: look for a get_data() function (convention used by
    # auto-generated apps) and register whatever it returns.
    seen_func_ids: set = set()
    for ns_name, namespace in _discoverable_namespaces():
        get_data = namespace.get("get_data")
        if get_data is None or not callable(get_data):
            continue
        func_id = id(get_data)
        if func_id in seen_func_ids:
            continue
        seen_func_ids.add(func_id)
        try:
            result = get_data()
        except Exception:
            _logger.debug(
                "Auto-discovery: skipping get_data from module %r (call raised exception)",
                ns_name,
            )
            continue

        registered_any = False
        for name, obj in _unwrap_get_data_result(result, ns_name):
            if name in existing:
                continue
            if _auto_register(name, obj, ns_name):
                existing.add(name)
                registered_any = True
        if registered_any:
            break
