"""Publishing adapters for Plotly Cloud and Dash Enterprise.

This sub-package isolates all deployment logic behind two async entry points:

- :func:`publish_to_cloud` — wraps a chart/table in a minimal Dash app and
  deploys it to Plotly Cloud via the ``POST /api/app`` REST endpoint.
- :func:`publish_to_de` — deploys the same Dash app to a Dash Enterprise
  instance by registering it via GraphQL and pushing via ``git``.
- :func:`get_cloud_app_status` — polls the Plotly Cloud deployment status
  for a previously published app.
"""

from ._cloud import get_cloud_app_status, publish_to_cloud
from ._de import get_de_app_status, publish_to_de

__all__ = ["get_cloud_app_status", "get_de_app_status", "publish_to_cloud", "publish_to_de"]
