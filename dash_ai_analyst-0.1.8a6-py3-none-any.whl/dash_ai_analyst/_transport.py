"""Token management and HTTP transport for the LLM API client.

Provides :class:`TokenRefresher` — a mutable token holder with an optional
async refresh callback.  When the LLM API returns a 401, the transport calls
:meth:`TokenRefresher.refresh` to get a new access token and retries the
request once.  The caller can check :attr:`TokenRefresher.was_refreshed` after
the request completes and emit the updated token back to the browser.

Also provides :class:`_PlotlyTransport` (httpx transport),
:func:`make_openai_client` for building an :class:`openai.AsyncOpenAI` client,
and :func:`make_chat_model` for building a :class:`~langchain_openai.ChatOpenAI`
model — both pre-configured for Plotly Cloud's LLM gateway.
"""

import json
import logging
from typing import Any, Awaitable, Callable, Optional

import httpx
from langchain_openai import ChatOpenAI
from openai import AsyncOpenAI

from ._constants import USER_AGENT

logger = logging.getLogger(__name__)


class TokenRefresher:
    """Mutable access-token holder with transparent async refresh.

    Pass an instance to :func:`make_openai_client` (and hence to the transport)
    to enable transparent retry-on-401.  After the call returns, check
    :attr:`was_refreshed` to know whether a new token was issued, and if so
    read the new token from :attr:`access_token` to forward to the browser.

    Example::

        from dash_ai_analyst._transport import TokenRefresher
        from dash_ai_analyst._oauth import OAuthClient

        oauth = OAuthClient(CLIENT_ID)

        async def refresh():
            result = await oauth.refresh_access_token(stored_refresh_token)
            return result["access_token"]

        refresher = TokenRefresher(access_token, refresh)
        client = make_openai_client(access_token, api_base_url, refresher)
        # ... use client ...
        if refresher.was_refreshed:
            send_new_token_to_browser(refresher.access_token)
    """

    def __init__(
        self,
        access_token: str,
        refresh_callback: Optional[Callable[[], Awaitable[Optional[str]]]] = None,
    ) -> None:
        """Create a TokenRefresher.

        Args:
            access_token: The initial access token.
            refresh_callback: Async callable that returns a new access token
                string on success, or ``None`` / raises on failure.  When
                ``None``, refresh attempts always fail silently.
        """
        self.access_token = access_token
        self._refresh_callback = refresh_callback
        self.was_refreshed: bool = False

    async def refresh(self) -> bool:
        """Attempt to obtain a new access token via the refresh callback.

        Updates :attr:`access_token` in place on success and sets
        :attr:`was_refreshed` to ``True``.

        Returns:
            ``True`` if the token was successfully refreshed, ``False``
            otherwise (no callback, callback returned ``None``, or raised).
        """
        if not self._refresh_callback:
            return False
        try:
            new_token: Any = await self._refresh_callback()
            if new_token:
                self.access_token = new_token
                self.was_refreshed = True
                logger.debug("TokenRefresher: access token refreshed successfully")
                return True
        except Exception:
            logger.debug("TokenRefresher: refresh callback raised; treating as failed")
        return False


class _PlotlyTransport(httpx.AsyncHTTPTransport):
    """Custom HTTP transport for LLM API endpoints.

    On every request:
    - Optionally strips ``X-Stainless-*`` and ``OpenAI-*`` headers (added by
      the openai SDK but rejected by Plotly Cloud's Cloudflare configuration).
    - Sets ``User-Agent: PlotlyStudio`` (required by Plotly Cloud).
    - Injects ``Authorization: Bearer {token}``.
    - Injects ``origin_source: "dash"`` into the JSON body if absent.
    - Injects ``team_id`` into the JSON body if provided and not already set.

    On 401: calls :meth:`TokenRefresher.refresh` and retries once.
    """

    _STRIP_PREFIXES = ("x-stainless-", "openai-")

    def __init__(
        self,
        refresher: TokenRefresher,
        strip_sdk_headers: bool = True,
        team_id: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self._refresher = refresher
        self._strip_sdk_headers = strip_sdk_headers
        self._team_id = team_id

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        request = self._patched(request)
        response = await super().handle_async_request(request)
        if response.status_code == 401:
            # Drain the response body so the connection can be reused.
            await response.aread()
            if await self._refresher.refresh():
                request = self._patched(request)
                response = await super().handle_async_request(request)
        return response

    def _patched(self, request: httpx.Request) -> httpx.Request:
        """Return a new request with sanitized headers, injected auth, and origin_source."""
        try:
            body_bytes = request.content
            body = json.loads(body_bytes)
            if isinstance(body, dict):
                if "origin_source" not in body:
                    body["origin_source"] = "plotly_studio_embedded"
                if self._team_id:
                    props = body.setdefault("additional_properties", {})
                    if "team_id" not in props:
                        props["team_id"] = self._team_id
            body_bytes = json.dumps(body).encode()
        except Exception:
            body_bytes = request.content if hasattr(request, "content") else b""

        if self._strip_sdk_headers:
            headers = {
                k: v for k, v in request.headers.items()
                if not k.lower().startswith(self._STRIP_PREFIXES)
                and k.lower() != "content-length"
            }
        else:
            headers = {k: v for k, v in request.headers.items() if k.lower() != "content-length"}
        headers["user-agent"] = USER_AGENT
        headers["authorization"] = f"Bearer {self._refresher.access_token}"
        headers["content-length"] = str(len(body_bytes))
        return httpx.Request(
            method=request.method,
            url=request.url,
            headers=headers,
            content=body_bytes,
        )


def make_openai_client(
    access_token: str,
    api_base_url: str,
    token_refresher: Optional[TokenRefresher] = None,
    strip_sdk_headers: bool = True,
    team_id: Optional[str] = None,
) -> AsyncOpenAI:
    """Create an :class:`openai.AsyncOpenAI` client for an LLM API endpoint.

    Args:
        access_token: The viewer's current access token.
        api_base_url: Full base URL for the OpenAI-compatible endpoint,
            e.g. ``"https://cloud.plotly.com/api/ai"`` (Plotly Cloud) or
            ``"https://my-de.example.com/my-proxy/api/ai"`` (DE proxy).
        token_refresher: Optional refresher.  When ``None``, a non-refreshing
            refresher is created from *access_token*.
        strip_sdk_headers: Strip ``X-Stainless-*`` / ``OpenAI-*`` headers
            added by the openai SDK.  Required for Plotly Cloud (Cloudflare
            blocks them); set to ``False`` for DE proxies.

    Returns:
        A configured :class:`~openai.AsyncOpenAI` instance.
    """
    refresher = token_refresher or TokenRefresher(access_token)
    transport = _PlotlyTransport(refresher, strip_sdk_headers=strip_sdk_headers, team_id=team_id)
    http_client = httpx.AsyncClient(transport=transport)
    return AsyncOpenAI(
        base_url=api_base_url,
        api_key="placeholder",  # auth is injected by the transport
        http_client=http_client,
    )


def make_plotly_cloud_client(
    access_token: str,
    api_base_host: str,
    token_refresher: Optional[TokenRefresher] = None,
    team_id: Optional[str] = None,
) -> AsyncOpenAI:
    """Create an OpenAI client pre-configured for Plotly Cloud's LLM gateway."""
    return make_openai_client(
        access_token=access_token,
        api_base_url=f"https://{api_base_host}/api/ai",
        token_refresher=token_refresher,
        strip_sdk_headers=True,
        team_id=team_id,
    )


def make_de_client(
    access_token: str,
    de_proxy_url: str,
    token_refresher: Optional[TokenRefresher] = None,
) -> AsyncOpenAI:
    """Create an OpenAI client for a DE proxy using a Keycloak bearer token."""
    return make_openai_client(
        access_token=access_token,
        api_base_url=de_proxy_url,
        token_refresher=token_refresher,
        strip_sdk_headers=False,
    )


# ---------------------------------------------------------------------------
# LangChain ChatOpenAI model factories
# ---------------------------------------------------------------------------


def make_chat_model(
    access_token: str,
    api_base_url: str,
    model_id: str,
    token_refresher: Optional[TokenRefresher] = None,
    strip_sdk_headers: bool = True,
    team_id: Optional[str] = None,
) -> ChatOpenAI:
    """Create a :class:`~langchain_openai.ChatOpenAI` for an LLM API endpoint.

    Uses the same :class:`_PlotlyTransport` as :func:`make_openai_client`
    so that auth injection, header sanitization, and 401-retry all work
    identically.

    Args:
        access_token: The viewer's current access token.
        api_base_url: Full base URL for the OpenAI-compatible endpoint.
        model_id: Model identifier forwarded to the gateway.
        token_refresher: Optional refresher for transparent 401 retry.
        strip_sdk_headers: Strip ``X-Stainless-*`` / ``OpenAI-*`` headers.
    """
    refresher = token_refresher or TokenRefresher(access_token)
    transport = _PlotlyTransport(refresher, strip_sdk_headers=strip_sdk_headers, team_id=team_id)
    http_client = httpx.AsyncClient(transport=transport)
    return ChatOpenAI(
        model=model_id,
        base_url=api_base_url,
        api_key="placeholder",
        http_async_client=http_client,
        # Always stream requests to the gateway.  Its non-streaming handler
        # fails on large agentic conversations (many/large tool results) with
        # a `filter_error: Message must have either 'content' or 'tool_calls'`;
        # the streaming endpoint handles the identical payload correctly.
        streaming=True,
    )


def make_plotly_cloud_chat_model(
    access_token: str,
    api_base_host: str,
    model_id: str,
    token_refresher: Optional[TokenRefresher] = None,
    team_id: Optional[str] = None,
) -> ChatOpenAI:
    """Create a ChatOpenAI model pre-configured for Plotly Cloud's LLM gateway."""
    return make_chat_model(
        access_token=access_token,
        api_base_url=f"https://{api_base_host}/api/ai",
        model_id=model_id,
        token_refresher=token_refresher,
        strip_sdk_headers=True,
        team_id=team_id,
    )


def make_de_chat_model(
    access_token: str,
    de_proxy_url: str,
    model_id: str,
    token_refresher: Optional[TokenRefresher] = None,
) -> ChatOpenAI:
    """Create a ChatOpenAI model for a DE proxy using a Keycloak bearer token."""
    return make_chat_model(
        access_token=access_token,
        api_base_url=de_proxy_url,
        model_id=model_id,
        token_refresher=token_refresher,
        strip_sdk_headers=False,
    )

