"""create_chart tool — render a SQL query result as a Plotly chart."""

import json
import math
from typing import Any, Dict, List, Optional

import pandas as pd
from langchain.tools import ToolRuntime, tool

from .._constants import MAX_ROWS
from ._context import AgentContext, StoredOutput, _new_handle, _store
from ._db import execute_query

def _parse_json_strings(obj: Any) -> Any:
    """Recursively parse JSON string values inside dicts/lists.

    DuckDB struct columns arrive as Python dicts, but fields cast via
    ``::JSON`` (e.g. ``ST_AsGeoJSON(geom)::JSON``) remain as strings.
    This converts them into nested dicts/lists so Plotly receives proper
    objects rather than serialized JSON text.

    Only applied when a column reference uses the ``:json`` suffix
    (e.g. ``"$geo.feature:json"``), so ordinary string values inside
    structs are never accidentally parsed.
    """
    if isinstance(obj, dict):
        return {k: _parse_json_strings(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_parse_json_strings(item) for item in obj]
    if isinstance(obj, str):
        try:
            parsed = json.loads(obj)
            if isinstance(parsed, (dict, list)):
                return parsed
        except (json.JSONDecodeError, ValueError):
            pass
    return obj


def _col_values(series: Any) -> list:
    """Convert a pandas Series to a JSON-serializable list.

    Non-finite floats become ``None``, the same treatment ``query_data``
    and ``display_table`` give them via ``df_to_json_safe``.  ``NaN`` and
    ``Infinity`` are not JSON per RFC 8259: Python's ``json.dumps`` writes
    them as bare tokens that ``JSON.parse`` rejects, so a single infinity
    in a column would drop the whole SSE event and the chart would never
    arrive.  DuckDB's ``/`` returns infinity rather than raising on a zero
    denominator, so this is a query away, not a corner case.
    """
    result = []
    for v in series:
        try:
            if pd.isna(v):
                result.append(None)
                continue
        except (TypeError, ValueError):
            pass
        if hasattr(v, "item"):
            v = v.item()
        if isinstance(v, float) and not math.isfinite(v):
            result.append(None)
        elif hasattr(v, "isoformat"):
            result.append(v.isoformat())
        else:
            result.append(v)
    return result


def _resolve(value: Any, dfs: Dict[str, pd.DataFrame]) -> Any:
    """Resolve a ``"$name.col"`` or ``"$name.col:json"`` reference.

    The ``:json`` suffix triggers recursive parsing of JSON strings
    inside the resolved values (e.g. DuckDB struct columns containing
    ``ST_AsGeoJSON()::JSON`` fields).
    """
    if not isinstance(value, str) or not value.startswith("$"):
        return value
    ref = value[1:]
    parse_json = ref.endswith(":json")
    if parse_json:
        ref = ref[: -len(":json")]
    if "." in ref:
        name, col = ref.split(".", 1)
        df = dfs.get(name)
        if df is not None and col in df.columns:
            values = _col_values(df[col])
            if parse_json:
                return [_parse_json_strings(v) for v in values]
            return values
    return value


def _substitute(obj: Any, dfs: Dict[str, pd.DataFrame]) -> Any:
    """Recursively walk a figure spec, resolving ``$name.col`` references."""
    if isinstance(obj, str):
        return _resolve(obj, dfs)
    if isinstance(obj, dict):
        return {k: _substitute(v, dfs) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_substitute(item, dfs) for item in obj]
    return obj


def _collect_ref_names(obj: Any) -> set:
    """Return the set of query names used in ``$name.col`` references."""
    if isinstance(obj, str) and obj.startswith("$"):
        ref = obj[1:].split(":")[0]  # strip optional :json suffix
        if "." in ref:
            return {ref.split(".", 1)[0]}
        return set()
    if isinstance(obj, dict):
        result: set = set()
        for v in obj.values():
            result |= _collect_ref_names(v)
        return result
    if isinstance(obj, list):
        result = set()
        for item in obj:
            result |= _collect_ref_names(item)
        return result
    return set()


# ---------------------------------------------------------------------------
# Post-substitution figure checks
#
# The tool returns before anything is drawn, so a figure Plotly refuses to
# render comes back as "chart created" and the model moves on believing it
# worked.  These run on the resolved figure and raise instead, which reaches
# the model as a tool error it can act on.
# ---------------------------------------------------------------------------

#: Fields that decide whether a trace draws anything at all.  ``text`` or
#: ``customdata`` may legitimately be all-null; these may not.
_ESSENTIAL_TRACE_FIELDS = (
    "x", "y", "z", "values", "labels", "lat", "lon", "locations",
    "r", "theta", "a", "b", "c", "open", "high", "low", "close",
)

#: Trace types Plotly builds a tree for, and so needs a single root from.
_HIERARCHY_TYPES = {"treemap", "sunburst", "icicle"}


def _check_no_blank_traces(figure: Dict[str, Any]) -> None:
    """Reject a figure whose plotted values are entirely null.

    A column that is all NULL — or all non-finite, which ``_col_values``
    turns into null — renders as an empty plot area with axes and no
    marks.
    """
    blanks: List[str] = []
    for i, trace in enumerate(figure.get("data") or []):
        if not isinstance(trace, dict):
            continue
        for field in _ESSENTIAL_TRACE_FIELDS:
            value = trace.get(field)
            if isinstance(value, list) and value and all(v is None for v in value):
                blanks.append(f"trace {i} '{field}'")
    if blanks:
        raise ValueError(
            f"These values are entirely null, so the chart would render empty: "
            f"{', '.join(blanks)}. Either the column is all NULL, or it is all "
            "non-finite — division by zero gives infinity in DuckDB rather than "
            "an error, and infinity cannot be plotted. Guard the denominator "
            "with `x / NULLIF(y, 0)`, or filter the null rows out with a WHERE "
            "clause, then create the chart again."
        )


def _is_hierarchy_key(value: Any) -> bool:
    """Plotly's ``isValidKey``: anything truthy, and ``0`` as well."""
    return bool(value) or value == 0


def _check_hierarchy_traces(figure: Dict[str, Any]) -> None:
    """Reject a treemap/sunburst/icicle Plotly cannot build a tree from.

    Mirrors the rules in Plotly's ``sunburst/calc.js``, which treemap and
    icicle share.  A parent naming something that is not itself a node is an
    *implied* root: Plotly invents the node when there is exactly one, and
    gives up when there are several — "Multiple implied roots, cannot build
    treemap hierarchy of trace 0".  Several rows with an empty parent are
    fine by contrast; Plotly joins them under a dummy root of its own.

    It reports the failure through ``Lib.warn``, which Plotly's default log
    level does not even print, and returns an empty chart.  So the model is
    told the chart was created, the console usually says nothing, and what
    the viewer gets is a blank card.  Hence checking it here.
    """
    for i, trace in enumerate(figure.get("data") or []):
        if not isinstance(trace, dict) or trace.get("type") not in _HIERARCHY_TYPES:
            continue
        parents = trace.get("parents")
        # Parents are matched against `ids` when given and against `labels`
        # otherwise — Plotly's own precedence.
        ids = trace.get("ids")
        keys = ids if isinstance(ids, list) else trace.get("labels")
        if not isinstance(parents, list) or not isinstance(keys, list):
            continue

        where = f"trace {i} ({trace.get('type')})"
        if len(keys) != len(parents):
            raise ValueError(
                f"{where}: 'parents' has {len(parents)} values but there are "
                f"{len(keys)} nodes. Plotly drops the excess silently, so take "
                "both columns from one query and give every node one parent."
            )

        rows = [(str(k), p) for k, p in zip(keys, parents) if _is_hierarchy_key(k)]
        if not rows:
            continue

        # Duplicate names are not checked here.  They cost rows — a repeat is
        # dropped rather than drawn — but Plotly does render the chart, and
        # refusing one it would have drawn is the worse failure of the two.
        # The system prompt asks for unique names instead.
        node_ids = {k for k, _ in rows}

        # A row with an empty parent puts the tree's top in the data, and any
        # number of those is fine.  Only when there are none does Plotly go
        # looking for a root to infer.
        if any(not _is_hierarchy_key(p) for _, p in rows):
            continue

        implied = list(dict.fromkeys(str(p) for _, p in rows if str(p) not in node_ids))
        if len(implied) == 1:
            continue
        if not implied:
            raise ValueError(
                f"{where}: every parent is also a node, so the tree closes on "
                "itself and has no top. Give the top-level rows '' as their "
                "parent."
            )
        raise ValueError(
            f"{where}: {len(implied)} parents name something that is not a node "
            f"in this trace ({', '.join(implied[:8])}), which leaves Plotly with "
            "several roots and it draws nothing. Either add a row for each of "
            "those parents with '' as its own parent — "
            "`UNION ALL SELECT DISTINCT region, ''` — or, if they are already "
            "meant to be the top level, use '' as their parent instead."
        )


@tool
def create_chart(
    queries: Dict[str, str],
    figure: Dict[str, Any],
    title: Optional[str] = None,
    runtime: ToolRuntime[AgentContext] = None,  # type: ignore[assignment]
) -> str:
    """Create a Plotly chart from one or more named SQL queries and a Plotly figure spec.

    Args:
        queries: A dict mapping query names to SQL strings, e.g.
            ``{"africa": "SELECT ...", "europe": "SELECT ..."}``.
            Each name is used as a prefix in column references within
            ``figure`` (``"$name.col"``).  Must be non-empty.
        figure: A Plotly figure dict with ``data`` (list of traces) and
            optionally ``layout``.

            **Column references** — any data-array field (``x``, ``y``, ``z``,
            ``text``, ``values``, ``labels``, ``locations``, ``lat``, ``lon``,
            ``marker.size``, etc.) accepts ``"$name.col"`` which draws ``col``
            from the named query result.  Each reference resolves to the
            **entire column as a flat list** (one element per row) — it is
            never a single scalar.  Append ``:json`` to parse JSON strings
            into objects (e.g. ``"$geo.feature:json"`` for GeoJSON).

            Supports all Plotly trace types (``scatter``, ``bar``, ``pie``,
            ``heatmap``, ``box``, ``violin``, ``waterfall``, ``funnel``,
            ``indicator``, ``candlestick``, ``choroplethmap``,
            ``scattermap``, etc.), multiple traces, annotations, shapes,
            and full layout control.
        title: Convenience title — sets ``layout.title.text`` if
            ``layout.title`` is not already present in ``figure``.
    """
    ctx = runtime.context

    if not queries:
        raise ValueError(
            "`queries` must not be empty — provide at least one named SQL query. "
            'Example: queries={"data": "SELECT col1, col2 FROM my_table"}'
        )

    if not isinstance(figure.get("data"), list) or not figure["data"]:
        raise ValueError(
            "`figure` must contain a non-empty 'data' list with at least one trace. "
            'Example: figure={"data": [{"type": "bar", "x": "$data.col1", "y": "$data.col2"}]}'
        )

    unknown_names = _collect_ref_names(figure) - set(queries.keys())
    if unknown_names:
        raise ValueError(
            f"Figure references unknown query name(s): {', '.join(sorted(unknown_names))}. "
            f"Names defined in 'queries': {', '.join(queries.keys())}. "
            "Each '$name.col' reference must use a name that is a key in 'queries'."
        )

    dfs: Dict[str, pd.DataFrame] = {}
    for name, sql in queries.items():
        df = execute_query(sql, ctx.scope, ctx.secrets)
        if len(df) > MAX_ROWS:
            raise ValueError(
                f"Query '{name}' returned {len(df):,} rows, which exceeds the {MAX_ROWS:,}-row "
                "limit. Please refine your query — add a WHERE clause, GROUP BY aggregation, or LIMIT."
            )
        if df.empty:
            raise ValueError(f"Query '{name}' returned an empty result — cannot create a chart.")
        dfs[name] = df

    figure = _substitute(figure, dfs)
    _check_no_blank_traces(figure)
    _check_hierarchy_traces(figure)

    # Apply title if the figure spec doesn't already define one.
    if title and not figure.get("layout", {}).get("title"):
        figure.setdefault("layout", {})["title"] = {"text": title}

    chart_handle = _new_handle("fig")
    serialized: Dict[str, Any] = {
        "queries": json.dumps(queries),
        "figure_spec": json.dumps(figure),
        "chart": figure,
        "title": title or "",
    }
    _store(ctx, StoredOutput(handle=chart_handle, type="figure", data=figure, serialized=serialized))

    return json.dumps({
        "handle": chart_handle,
        "type": "figure",
        "description": f"Created chart: {title or 'Untitled'}",
        "columns_available": {name: list(df.columns) for name, df in dfs.items()},
    })
