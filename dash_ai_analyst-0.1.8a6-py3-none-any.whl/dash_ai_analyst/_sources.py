"""External data source descriptors for :func:`register_data`."""

from dataclasses import dataclass, field
from typing import Tuple


@dataclass(frozen=True)
class Source:
    """A data source accessible via DuckDB's ATTACH statement.

    Wraps any database that DuckDB can attach — DuckDB files, PostgreSQL,
    MySQL, and any other type supported by DuckDB extensions.

    Args:
        connection_string: For DuckDB files, the path to the ``.duckdb``
            file.  For other database types, the connection string accepted
            by that extension (e.g. a libpq string for PostgreSQL or a
            key=value string for MySQL).
        db_type: DuckDB ATTACH ``TYPE`` parameter.  Defaults to
            ``"duckdb"`` (native file).  Set to ``"postgres"`` or
            ``"mysql"`` (or any other installed extension type) for
            external databases.
        setup: Ordered SQL statements executed **before** the ATTACH on
            each fresh per-request connection.  Use this for ``INSTALL``,
            ``LOAD``, ``FORCE INSTALL … FROM '…'``, ``CREATE SECRET``,
            ``SET``, or any other prerequisite DuckDB commands.  Statements
            are developer-provided and trusted — they are **not** subject
            to the SELECT-only validation applied to LLM-generated queries.

    Examples::

        # DuckDB file
        Source("analytics.duckdb")

        # PostgreSQL
        Source("host=localhost port=5432 dbname=mydb user=analyst", db_type="postgres")

        # MySQL
        Source("host=localhost database=myapp user=root password=s3cr3t", db_type="mysql")

        # PostgreSQL with explicit extension setup
        Source(
            "host=localhost dbname=mydb",
            db_type="postgres",
            setup=("INSTALL postgres", "LOAD postgres"),
        )
    """

    connection_string: str
    db_type: str = field(default="duckdb")
    setup: Tuple[str, ...] = field(default=())
