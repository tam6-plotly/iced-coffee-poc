"""Shared constants for the Dash AI Analyst backend."""

import os

# ---------------------------------------------------------------------------
# Keycloak (Dash Enterprise auth)
# ---------------------------------------------------------------------------

KEYCLOAK_REALM = "dash"
KEYCLOAK_CLIENT_ID = "dash"
KEYCLOAK_SCOPE = "openid offline_access"
KEYCLOAK_GRANT_DEVICE = "urn:ietf:params:oauth:grant-type:device_code"
KEYCLOAK_GRANT_REFRESH = "refresh_token"

# ---------------------------------------------------------------------------
# Plotly Cloud / API
# ---------------------------------------------------------------------------

# The Plotly Cloud API host this app is deployed against, for authentication and APIs.
API_FQDN = os.environ.get("PLOTLY_API_FQDN") or "cloud.plotly.com"

# Alias kept for the call sites that interpolate the host into a URL themselves.
API_BASE_URL = API_FQDN

# Domain each Plotly Cloud environment serves its apps from by default.
# Used to build links to newly published artifacts.
PRODUCTION_APP_DOMAIN = "plotly.app"
_APP_DOMAINS_BY_HOST = {
    "cloud.plotly.com": PRODUCTION_APP_DOMAIN,
    "staging-cloud.plotly.host": "staging-plotly.cloud",
    "api.cloud.plotly.local": "apps.plotly.local",
}

# Per-pull-request Plotly Cloud environments are named pr-<number>-cloud.plotly.host
# and serve their apps from pr-<number>.dev-plotly.cloud.
_PR_HOST_SUFFIX = "-cloud.plotly.host"
_PR_APP_DOMAIN_SUFFIX = ".dev-plotly.cloud"


def _app_domain(api_fqdn: str) -> str:
    """Pick the domain a Plotly Cloud host serves its apps from.

    Falls back to the production domain for any host that is not recognised.
    """
    if api_fqdn in _APP_DOMAINS_BY_HOST:
        return _APP_DOMAINS_BY_HOST[api_fqdn]
    if api_fqdn.endswith(_PR_HOST_SUFFIX):
        return api_fqdn[: -len(_PR_HOST_SUFFIX)] + _PR_APP_DOMAIN_SUFFIX
    return PRODUCTION_APP_DOMAIN


APP_DOMAIN = _app_domain(API_FQDN)

# WorkOS clients for viewer sign-in, one per Plotly Cloud environment.
PRODUCTION_OAUTH_CLIENT_ID = "client_01JBHED1ZCBXX7811MDKFJ74SG"
STAGING_OAUTH_CLIENT_ID = "client_01JBHED1RSCQ8H0T2W8ZQST4WM"
DEV_OAUTH_CLIENT_ID = "client_01K4D7G95AYV5T48SDYMF3E4SN"

_OAUTH_CLIENT_IDS_BY_HOST = {
    "cloud.plotly.com": PRODUCTION_OAUTH_CLIENT_ID,
    "staging-cloud.plotly.host": STAGING_OAUTH_CLIENT_ID,
    "api.cloud.plotly.local": DEV_OAUTH_CLIENT_ID,
}


def _oauth_client_id(api_fqdn: str) -> str:
    """Pick the WorkOS client for a Plotly Cloud host.

    Falls back to the production client for any host that is not recognised, which
    keeps deployments Plotly Cloud does not manage working as they did before
    PLOTLY_API_FQDN existed.
    """
    if api_fqdn in _OAUTH_CLIENT_IDS_BY_HOST:
        return _OAUTH_CLIENT_IDS_BY_HOST[api_fqdn]
    if api_fqdn.endswith(_PR_HOST_SUFFIX):
        return DEV_OAUTH_CLIENT_ID
    return PRODUCTION_OAUTH_CLIENT_ID


OAUTH_CLIENT_ID = _oauth_client_id(API_FQDN)


# ---------------------------------------------------------------------------
# WorkOS (OAuth provider)
# ---------------------------------------------------------------------------

WORKOS_API_BASE_URL = "https://api.workos.com"
WORKOS_LOGOUT_URL = f"{WORKOS_API_BASE_URL}/user_management/sessions/logout"
WORKOS_ENDPOINTS = {
    "DEVICE_AUTHORIZE": "/user_management/authorize/device",
    "AUTHENTICATE": "/user_management/authenticate",
    "REFRESH_TOKEN": "/user_management/authenticate",
}
DEFAULT_AUTH_PROVIDER = "authkit"

# Assumed access-token lifetime, in seconds, when the token carries no
# readable ``exp`` claim.
FALLBACK_TOKEN_LIFETIME = 300

# HTTP User-Agent sent to Plotly Cloud (required by Cloudflare config).
USER_AGENT = "PlotlyStudio"

# ---------------------------------------------------------------------------
# LLM
# ---------------------------------------------------------------------------

DEFAULT_MODEL = "claude-opus-4-5"

# ---------------------------------------------------------------------------
# Query result limits
# ---------------------------------------------------------------------------

# Number of rows shown to the LLM or sent to the frontend as a preview.
PREVIEW_ROWS = 100

# Hard upper limit on result size before saving/storing data.  Queries
# returning more rows than this raise an error so the LLM can refine rather
# than silently truncating or transferring too much data.
MAX_ROWS = 1_000_000

# ---------------------------------------------------------------------------
# Flask / SSE routes
# ---------------------------------------------------------------------------

# Route names as registered with Dash (no leading slash).
ROUTE_RPC = "_dash_ai_analyst"
ROUTE_STREAM = "_dash_ai_analyst_stream"
# URL paths used in fetch() calls from the browser (leading slash included).
RPC_URL = f"/{ROUTE_RPC}"
STREAM_URL = f"/{ROUTE_STREAM}"
