"""query_data tool — execute DuckDB SQL and return a preview."""

import json

from langchain.tools import ToolRuntime, tool

from .._constants import MAX_ROWS, PREVIEW_ROWS
from ._context import AgentContext
from ._db import df_to_json_safe, execute_query


@tool
def query_data(
    query: str,
    runtime: ToolRuntime[AgentContext] = None,  # type: ignore[assignment]
) -> str:
    """Execute a DuckDB SQL query against the registered datasets.

    Args:
        query: DuckDB SQL. Use plain unquoted table names — backticks are
            invalid in DuckDB.

    Raises:
        ValueError: If the query returns more than 1,000,000 rows.  Add a
            WHERE clause, a GROUP BY aggregation, or a LIMIT to narrow the
            result.
    """
    ctx = runtime.context
    result_df = execute_query(query, ctx.scope, ctx.secrets)

    if len(result_df) > MAX_ROWS:
        raise ValueError(
            f"Query returned {len(result_df):,} rows, which exceeds the {MAX_ROWS:,}-row limit. "
            "Please refine your query — add a WHERE clause, GROUP BY aggregation, or LIMIT."
        )

    columns = list(result_df.columns)
    preview = df_to_json_safe(result_df.head(PREVIEW_ROWS))

    return json.dumps({
        "row_count": len(result_df),
        "columns": columns,
        "preview": preview,
    })
