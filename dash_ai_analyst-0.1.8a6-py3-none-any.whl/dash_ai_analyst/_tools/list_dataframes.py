"""list_dataframes tool — discover registered datasets and their schemas."""

import json

from langchain.tools import ToolRuntime, tool

from .._registry import get_all_metadata
from ._context import AgentContext


@tool
def list_dataframes(runtime: ToolRuntime[AgentContext]) -> str:
    """List all available datasets with their column information.

    Use this first to discover which datasets are registered and their schemas.
    Returns name, description, row count, and column names/types for each dataset.
    """
    metadata = get_all_metadata(scope=runtime.context.scope)
    if not metadata:
        return json.dumps({"datasets": [], "message": "No datasets are currently registered."})

    datasets = []
    for meta in metadata:
        datasets.append({
            "name": meta["name"],
            "description": meta["description"],
            "row_count": meta["row_count"],
            "columns": [f"{c['name']} ({c['dtype']})" for c in meta["columns"]],
        })

    return json.dumps({"datasets": datasets})
