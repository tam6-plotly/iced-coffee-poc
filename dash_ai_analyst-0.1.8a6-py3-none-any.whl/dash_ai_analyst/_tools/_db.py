"""DuckDB query execution with per-request ephemeral connections."""

import logging
import os
import re
from typing import Any, Dict, Iterable, List, Optional, Set

import duckdb
import pandas as pd

from .._registry import (
    _ensure_extension,
    _get_registered_data_for_scope,
    _json_safe_value,
    _make_alias,
)
from .._secrets import SecretsMap, apply_secrets

_logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Query validation
# ---------------------------------------------------------------------------


def _validate_select_only(query: str) -> None:
    """Reject anything that isn't a single SELECT statement.

    Uses DuckDB's own parser via :func:`duckdb.extract_statements` so it
    correctly handles comments, CTEs, semicolons (multi-statement injection),
    and all DuckDB-specific syntax.
    """
    stmts = duckdb.extract_statements(query)
    if len(stmts) == 0:
        raise ValueError("Empty or invalid SQL query.")
    if len(stmts) != 1:
        raise ValueError(f"Expected a single SQL statement, got {len(stmts)}. Multi-statement queries are not allowed.")
    if stmts[0].type != duckdb.StatementType.SELECT:  # type: ignore[union-attr]
        raise ValueError(f"Only SELECT queries are allowed, got {stmts[0].type.name}.")


# ---------------------------------------------------------------------------
# Per-request connection factory
# ---------------------------------------------------------------------------


def _attach_df_entry(
    conn: duckdb.DuckDBPyConnection,
    name: str,
    db_path: str,
    alias: str,
) -> bool:
    """ATTACH a single DataFrame .duckdb file and create its VIEW.

    Returns True on success, False if the file has disappeared.
    """
    if not os.path.exists(db_path):
        return False
    try:
        conn.execute(f'ATTACH \'{db_path}\' AS "{alias}" (READ_ONLY)')
    except duckdb.IOException:
        return False
    conn.execute(
        f'CREATE VIEW main."{name}" '
        f'AS SELECT * FROM "{alias}".main."{name}"'
    )
    return True


def _referenced_names(query: str, names: Iterable[str]) -> Set[str]:
    """Return the registered dataset names that appear as identifiers in *query*.

    Only the datasets a query actually references need to be attached and
    viewed.  Building a plain-name VIEW for the *entire* catalog on every query
    does not scale: for an external Source with many tables, each
    ``CREATE VIEW ... AS SELECT * FROM <table>`` forces the scanner to
    introspect that table over the network, so even a trivial query would pay
    for many remote round-trips.

    Names are matched on word boundaries (``_`` counts as a word char, so
    ``bank_fact_loan`` does not match ``bank_fact_loan_repayment``).
    """
    return {
        name
        for name in names
        if re.search(rf"\b{re.escape(name)}\b", query, re.IGNORECASE)
    }


def _build_connection(
    scope: Optional[str],
    data_sources: Set[str],
    secrets: Optional[SecretsMap] = None,
) -> duckdb.DuckDBPyConnection:
    """Create a fresh DuckDB connection with the given datasets attached.

    Only the datasets named in *data_sources* are attached/viewed (see
    :func:`_referenced_names` for how callers typically derive this set from
    a query):

    1. For each Source, runs its ``setup`` SQL (INSTALL, LOAD, CREATE
       SECRET, etc.) — these need network and are developer-trusted.
    2. Falls back to ``_ensure_extension`` for Sources without ``setup``.
    3. ATTACHes DuckDB files for referenced DataFrames (READ_ONLY).
    4. ATTACHes external Sources with their type (READ_ONLY).
    5. Creates plain-name VIEWs so queries can use unqualified table names.
    6. Sets ``enable_external_access = false`` — **after** all setup/ATTACH.

    If a ``.duckdb`` file has been deleted by another worker since the
    last sync (race between time of check and time of use), the registry
    is re-synced from disk and the ATTACH is retried once with the replacement file.

    Global datasets are attached first; scoped datasets override by
    creating their views last.

    Args:
        scope: Registry scope key.
        data_sources: Names of registered datasets/sources to attach.
        secrets: Pre-resolved ``{{placeholder}}`` values (thread-safe).
    """
    conn = duckdb.connect()

    all_registered = _get_registered_data_for_scope(scope)

    if any(
        all_registered[name].get("needs_spatial")
        for name in data_sources
        if name in all_registered
    ):
        conn.execute("INSTALL spatial; LOAD spatial;")

    alias_counter = 0

    def _next_alias(prefix: str) -> str:
        nonlocal alias_counter
        alias_counter += 1
        return f"_da_{prefix}_{alias_counter}"

    # Track which source aliases we've already ATTACHed so we don't
    # duplicate when multiple tables come from the same external source.
    attached_source_aliases: Dict[str, str] = {}

    for name in list(all_registered):
        if name not in data_sources:
            continue
        entry = all_registered.get(name)
        if entry is None:
            continue

        if entry.get("duckdb_path"):
            db_path: str = entry["duckdb_path"]  # type: ignore[assignment]
            alias = _next_alias("ds")
            if not _attach_df_entry(conn, name, db_path, alias):
                all_registered = _get_registered_data_for_scope(scope)
                entry = all_registered.get(name)
                if entry is None:
                    _logger.warning(
                        "Dataset %r no longer registered after re-sync",
                        name,
                    )
                    continue
                new_path: Optional[str] = entry.get("duckdb_path")  # type: ignore[assignment]
                if new_path and new_path != db_path:
                    alias = _next_alias("ds")
                    if not _attach_df_entry(conn, name, new_path, alias):
                        _logger.warning(
                            "Dataset %r unavailable after re-sync "
                            "(file %s also missing)", name, new_path,
                        )
                else:
                    _logger.warning(
                        "Dataset %r unavailable (file %s missing, "
                        "no replacement found)", name, db_path,
                    )

        elif entry.get("source") and entry.get("source_tables"):
            source = entry["source"]  # type: ignore[assignment]
            src_alias_key = entry.get("attach_alias") or _make_alias(
                source.connection_string,
                source.db_type,
            )

            if src_alias_key not in attached_source_aliases:
                for stmt in source.setup:
                    conn.execute(apply_secrets(stmt, scope, secrets))
                _ensure_extension(conn, source.db_type)
                type_clause = (
                    f", TYPE {source.db_type}" if source.db_type != "duckdb" else ""
                )
                resolved_conn_str = apply_secrets(
                    source.connection_string,
                    scope,
                    secrets,
                )
                conn.execute(
                    f"ATTACH '{resolved_conn_str}' "
                    f'AS "{src_alias_key}" (READ_ONLY{type_clause})'
                )
                attached_source_aliases[src_alias_key] = src_alias_key

            for db_schema, table_name in entry["source_tables"]:
                conn.execute(
                    f'CREATE OR REPLACE VIEW main."{name}" '
                    f'AS SELECT * FROM "{src_alias_key}"."{db_schema}"."{table_name}"'
                )

    conn.execute("SET enable_external_access = false")

    return conn


# ---------------------------------------------------------------------------
# Public query API
# ---------------------------------------------------------------------------


def execute_query(
    query: str,
    scope: Optional[str] = None,
    secrets: Optional[SecretsMap] = None,
) -> pd.DataFrame:
    """Execute a SQL query against a fresh per-request DuckDB connection.

    Creates an ephemeral connection with the datasets the query references
    attached, runs the query, and returns the result.

    Args:
        query: DuckDB SQL to execute.
        scope: Registry scope.
        secrets: Pre-resolved ``{{placeholder}}`` values (thread-safe).

    Returns:
        Full result DataFrame (caller applies row limit as needed).
    """
    _validate_select_only(query)
    data_sources = _referenced_names(query, _get_registered_data_for_scope(scope))
    conn = _build_connection(scope, data_sources, secrets)
    try:
        result = conn.execute(query)
        desc = result.description
        geom_indices = {
            i for i, d in enumerate(desc) if str(d[1]) == "GEOMETRY"
        }
        if not geom_indices:
            return result.df()

        # Wrap in a subquery that converts GEOMETRY → WKT text so the
        # resulting DataFrame is JSON-serializable and human-readable.
        cols = [d[0] for d in desc]
        parts = [
            f'ST_AsText("{c}") AS "{c}"' if i in geom_indices else f'"{c}"'
            for i, c in enumerate(cols)
        ]
        return conn.execute(
            f"SELECT {', '.join(parts)} FROM ({query}) AS __geom_wrap__"
        ).df()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------


def df_to_json_safe(df: pd.DataFrame) -> List[Dict[str, Any]]:
    """Convert a DataFrame to a JSON-serializable list of row dicts."""
    result = []
    for _, row in df.iterrows():
        row_dict: Dict[str, Any] = {}
        for col in df.columns:
            row_dict[col] = _json_safe_value(row[col])
        result.append(row_dict)
    return result
