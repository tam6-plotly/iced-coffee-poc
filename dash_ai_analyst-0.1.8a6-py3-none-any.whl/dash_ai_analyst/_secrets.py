"""Secret handling for Source connection strings and setup SQL.

This module centralises everything related to *secret values* — values
that the developer never wants to appear in logs, repr output, tracebacks,
or recipe files on disk:

* :class:`SecretStr` — a Pydantic-style wrapper whose ``__str__`` /
  ``__repr__`` render as ``***``.  The plaintext is reachable only via
  the explicit call :meth:`SecretStr.get_secret_value`.
* :func:`set_secret_resolver` — the developer-facing hook that turns
  ``{{placeholder}}`` tokens into concrete secret values at query time.
* :func:`apply_secrets` — substitute placeholders inside a SQL string
  with single-quote escaping.  Accepts both plain ``str`` and
  :class:`SecretStr` values in the *secrets* dict; unwraps lazily.
* :func:`retrieve_secrets` — eagerly resolve every placeholder
  referenced by Sources in a given scope, wrapping the returned values
  in :class:`SecretStr` so anything that subsequently logs the dict
  cannot leak the plaintext.
"""

from __future__ import annotations

import re
from typing import Callable, Mapping, Optional, Union

# ---------------------------------------------------------------------------
# SecretStr wrapper (Pydantic-style)
# ---------------------------------------------------------------------------


class SecretStr:
    """A string wrapper whose default rendering hides the plaintext.

    Modelled on ``pydantic.SecretStr``.  ``str()``, ``repr()``, ``%s``
    formatting, f-strings, ``logging``, and default JSON serialisation
    all emit ``'***'`` (or ``"SecretStr('***')"`` for ``repr``); the
    underlying value is accessible only via :meth:`get_secret_value`,
    which gives a single, easy-to-grep call site for any code path that
    legitimately needs the plaintext.

    Equality and hashing compare the underlying values so the wrapper
    composes with sets, dicts, and caches without leaking.
    """

    __slots__ = ("_secret_value",)

    _PLACEHOLDER = "***"

    def __init__(self, secret_value: str) -> None:
        self._secret_value = secret_value

    def get_secret_value(self) -> str:
        """Return the wrapped plaintext."""
        return self._secret_value

    def __str__(self) -> str:
        return self._PLACEHOLDER

    def __repr__(self) -> str:
        return f"SecretStr('{self._PLACEHOLDER}')"

    def __eq__(self, other: object) -> bool:
        if isinstance(other, SecretStr):
            return self._secret_value == other._secret_value
        if isinstance(other, str):
            return self._secret_value == other
        return NotImplemented

    def __hash__(self) -> int:
        return hash(self._secret_value)

    def __bool__(self) -> bool:
        return bool(self._secret_value)


# A resolved-secret value as it travels through the system: either a
# bare ``str`` (legacy callers / tests) or a :class:`SecretStr` wrapper.
SecretValue = Union[str, SecretStr]
SecretsMap = Mapping[str, SecretValue]


def _reveal(value: SecretValue) -> str:
    """Return the plaintext of *value*, unwrapping a :class:`SecretStr` if present."""
    if isinstance(value, SecretStr):
        return value.get_secret_value()
    return value


# ---------------------------------------------------------------------------
# Resolver registration
# ---------------------------------------------------------------------------

# Optional callback for resolving {{placeholder}} tokens in Source
# connection strings and setup SQL at query time.
_secret_resolver: Optional[Callable[[str, str], str]] = None


def set_secret_resolver(fn: Callable[[str, str], str]) -> None:
    """Register a callback that resolves ``{{placeholder}}`` tokens at query time.

    When a :class:`~dash_ai_analyst._sources.Source` connection string or
    ``setup`` SQL contains ``{{name}}`` tokens, the resolver is called with
    ``(scope_key, name)`` and the return value replaces the token.  This
    allows secrets to be injected dynamically without writing them to
    recipe files on disk.

    The resolver is module-level code — it is replicated to every worker
    automatically.  Recipe files contain only placeholder names; actual
    secret values are never persisted.

    Args:
        fn: ``(scope_key, placeholder_name) -> secret_value``.  *scope_key*
            is the registry scope string (``None`` is passed as ``""`` for
            global sources).

    Example::

        def my_resolver(scope: str, name: str) -> str:
            secrets = vault.get_secrets(f"users/{scope}/{name}")
            return {
                "db_user": secrets["DB_USER"],
                "db_password": secrets["DB_PASSWORD"],
            }[name]

        set_secret_resolver(my_resolver)
    """
    global _secret_resolver
    _secret_resolver = fn


def _get_resolver() -> Optional[Callable[[str, str], str]]:
    """Return the currently registered resolver (or ``None``)."""
    return _secret_resolver


# ---------------------------------------------------------------------------
# Placeholder substitution
# ---------------------------------------------------------------------------

# Matches ``{{name}}`` placeholders in Source connection strings and setup
# SQL.  The captured group is the placeholder name, looked up via the
# developer-provided secret resolver at query time so secrets never touch
# disk.
_PLACEHOLDER_RE = re.compile(r"\{\{(\w+)\}\}")


def apply_secrets(
    text: str,
    scope: Optional[str],
    secrets: Optional[SecretsMap] = None,
) -> str:
    """Replace ``{{placeholder}}`` tokens in *text*.

    Resolution order for each placeholder:

    1. *secrets* dict (pre-resolved values, thread-safe).  Values may be
       plain :class:`str` or :class:`SecretStr` — the wrapper is
       unwrapped lazily at substitution time.
    2. The callback registered via :func:`set_secret_resolver`.
    3. Leave the token as-is if neither source provides a value.

    Resolved values have single quotes escaped (``'`` → ``''``) so they
    are safe to embed in SQL string literals.
    """
    resolver = _secret_resolver
    has_resolver = resolver is not None
    if not has_resolver and not secrets:
        return text

    scope_key = scope or ""

    def _replace(m: "re.Match[str]") -> str:
        name = m.group(1)
        value: Optional[SecretValue] = None
        if secrets and name in secrets:
            value = secrets[name]
        elif resolver is not None:
            value = resolver(scope_key, name)
        if value is None:
            return m.group(0)
        return _reveal(value).replace("'", "''")

    return _PLACEHOLDER_RE.sub(_replace, text)


def retrieve_secrets(scope: Optional[str]) -> SecretsMap:
    """Eagerly resolve every ``{{placeholder}}`` referenced by Sources in *scope*.

    Scans the ``setup`` SQL and ``connection_string`` of every
    :class:`~dash_ai_analyst._sources.Source` visible in *scope*, calls
    the active secret resolver for each unique placeholder, and returns
    the results as a dict of :class:`SecretStr` wrappers — so callers
    can pass the dict around (logging, error context, repr) without
    leaking the plaintext.

    **Must be called while the resolver's backing context is available**
    (e.g. inside a Flask request).  The returned dict can then be passed
    to :func:`apply_secrets` from any thread.
    """
    resolver = _secret_resolver
    if resolver is None:
        return {}

    # Late import to avoid an import cycle (_registry imports from this
    # module).  The registry is the only place that knows which Sources
    # are in scope.
    from ._registry import _get_registered_data_for_scope

    registered = _get_registered_data_for_scope(scope)
    placeholders: set = set()
    for entry in registered.values():
        source = entry.get("source")
        if not source:
            continue
        for stmt in source.setup:
            placeholders.update(_PLACEHOLDER_RE.findall(stmt))
        placeholders.update(_PLACEHOLDER_RE.findall(source.connection_string))

    if not placeholders:
        return {}

    scope_key = scope or ""
    resolved: dict[str, SecretStr] = {}
    for name in placeholders:
        try:
            resolved[name] = SecretStr(resolver(scope_key, name))
        except Exception:
            pass
    return resolved
