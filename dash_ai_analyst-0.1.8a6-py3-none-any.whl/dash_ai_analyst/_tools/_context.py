"""Shared artifact types and context for the agent tool system."""

import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .._secrets import SecretsMap


@dataclass
class StoredOutput:
    """An in-memory result artifact created by a tool call.

    Attributes:
        handle: Unique identifier (used as the tool-result reference key).
        type: ``"figure"`` or ``"table"``.
        data: The actual in-memory object (figure dict or DataFrame).
            Not persisted to the browser; reconstructed from *serialized*.
        serialized: JSON-safe representation for browser persistence.
    """

    handle: str
    type: str
    data: Any
    serialized: Dict[str, Any]


@dataclass
class AgentContext:
    """Per-request context object passed via ``context_schema`` to the LangChain agent.

    Tools receive this through ``ToolRuntime[AgentContext]`` and mutate it
    in place to accumulate artifacts during a turn.

    Attributes:
        stored_outputs: Artifacts accumulated during this turn.
        scope: Registry scope key for per-viewer dataset isolation.
        secrets: Pre-resolved ``{{placeholder}}`` values keyed by
            placeholder name.  Populated once in the request context
            (before tool threads are spawned) so that resolvers that
            depend on Flask ``session`` or similar thread-local state
            do not need to run again inside executor threads.
        _new_handles: Handles added by the *most recent* tool call.
            Read by the event loop after each tool-output step and
            then cleared, so it always reflects the latest tool's outputs.
    """

    stored_outputs: Dict[str, StoredOutput] = field(default_factory=dict)
    scope: Optional[str] = None
    secrets: SecretsMap = field(default_factory=dict)
    app_state: Any = None
    _new_handles: List[str] = field(default_factory=list)


def _new_handle(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


def _store(ctx: AgentContext, output: StoredOutput) -> None:
    """Store an artifact in the agent context and track its handle."""
    ctx.stored_outputs[output.handle] = output
    ctx._new_handles.append(output.handle)
