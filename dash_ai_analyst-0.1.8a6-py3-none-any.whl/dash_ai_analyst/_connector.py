"""Authentication backend connectors.

Centralises all Plotly Cloud (WorkOS) and Dash Enterprise (Keycloak) specific
logic: stream credential resolution, initialize response fields, access-token
resolution for RPC calls, and chat-model creation.

Three concrete connectors are provided:

- :class:`ViewerCredentialConnector` *(default)* — viewers sign in with their
  own accounts; no developer credentials are held server-side.
- :class:`PlotlyCloudConnector` — WorkOS password grant; requires the optional
  ``workos`` package (``pip install "dash-ai-analyst[cloud]"``).
- :class:`DashEnterpriseConnector` — Keycloak ROPC grant; no extra package
  needed.
"""

import logging
import threading
import time
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional, Tuple

from ._constants import FALLBACK_TOKEN_LIFETIME
from ._oauth import get_exp_from_jwt

logger = logging.getLogger(__name__)


def _token_expiry(access_token: str, fallback_lifetime: Optional[int] = None) -> float:
    """Return the Unix timestamp at which ``access_token`` expires.

    Uses fallback_lifetime when the token carries no readable
    ``exp`` or FALLBACK_TOKEN_LIFETIME if no fallback is provided.
    """
    exp = get_exp_from_jwt(access_token)
    if exp is not None:
        return float(exp)
    return time.time() + (fallback_lifetime or FALLBACK_TOKEN_LIFETIME)


class Connector(ABC):
    """Abstract authentication backend connector.

    Subclass this to implement a custom authentication backend, or use one of
    the provided concrete classes.

    Four methods must be implemented:

    - :meth:`get_auth_init` — extra fields merged into the ``initialize`` RPC
      response (controls whether the browser shows a sign-in screen).
    - :meth:`get_stream_credentials` — resolves ``(access_token, refresh_token,
      de_proxy_url)`` for a streaming request.
    - :meth:`resolve_access_token` — returns the access token for a non-stream
      RPC call (publish, get_app_status).
    - :meth:`make_chat_model` — creates the LangChain ChatOpenAI model.
    """

    @abstractmethod
    def get_auth_init(self) -> Dict[str, Any]:
        """Return extra fields to merge into the ``initialize`` RPC response.

        :class:`ViewerCredentialConnector` returns ``{}`` so the browser shows
        the sign-in screen.  Developer connectors return
        ``{"auth_mode": "developer"}`` to skip it.
        """

    @abstractmethod
    def get_stream_credentials(self, data: Dict[str, Any]) -> Tuple[str, str, Optional[str]]:
        """Resolve ``(access_token, refresh_token, de_proxy_url)`` for a streaming request.

        For viewer connectors this reads tokens directly from the request.
        For developer connectors this fetches (or returns a cached) server-side
        token — the browser never sees it.

        Raises:
            Exception: If credentials are unavailable or authentication fails.
                The route handler catches this and returns a 401.
        """

    @abstractmethod
    def resolve_access_token(self, data: Dict[str, Any]) -> str:
        """Return the access token for a non-stream RPC call.

        Used by publish and get_app_status operations.  Viewer connectors
        return the token from the request; developer connectors return the
        server-side token.
        """

    @abstractmethod
    def make_chat_model(
        self,
        access_token: str,
        model_id: str,
        token_refresher: Any,  # TokenRefresher — avoids circular import
        *,
        de_proxy_url: Optional[str] = None,
        team_id: Optional[str] = None,
    ) -> Any:  # ChatOpenAI
        """Create a LangChain ChatOpenAI model for this backend.

        Args:
            access_token: The current access token.
            model_id: LLM model identifier forwarded to the gateway.
            token_refresher: :class:`~._transport.TokenRefresher` instance.
            de_proxy_url: Dash Enterprise LLM proxy URL.  When provided,
                the model routes through the DE proxy instead of Plotly Cloud.
            team_id: Plotly Cloud team ID (Cloud only; ignored by DE).
        """


class ViewerCredentialConnector(Connector):
    """Default connector: viewers sign in with their own accounts.

    No developer credentials are held server-side.  Each viewer authenticates
    interactively via the sign-in flow (Plotly Cloud device auth or Dash
    Enterprise device auth) and AI usage is billed to their own account.

    This is the connector used when no ``connector=`` is passed to
    :class:`~.AiAnalyst`.
    """

    def get_auth_init(self) -> Dict[str, Any]:
        return {}

    def get_stream_credentials(self, data: Dict[str, Any]) -> Tuple[str, str, Optional[str]]:
        return (
            data.get("access_token", ""),
            data.get("refresh_token", ""),
            data.get("de_proxy_url") or None,
        )

    def resolve_access_token(self, data: Dict[str, Any]) -> str:
        return data.get("access_token", "")

    def make_chat_model(
        self,
        access_token: str,
        model_id: str,
        token_refresher: Any,
        *,
        de_proxy_url: Optional[str] = None,
        team_id: Optional[str] = None,
    ) -> Any:
        from ._constants import API_BASE_URL
        from ._transport import make_de_chat_model, make_plotly_cloud_chat_model

        if de_proxy_url:
            return make_de_chat_model(access_token, de_proxy_url, model_id, token_refresher)
        return make_plotly_cloud_chat_model(
            access_token, API_BASE_URL, model_id, token_refresher, team_id=team_id
        )


class PlotlyCloudConnector(Connector):
    """Plotly Cloud (WorkOS) authentication connector.

    Authenticates viewers automatically using the developer's WorkOS credentials.
    Viewers never see a sign-in screen — AI usage is billed to the developer's
    Plotly Cloud account.

    Args:
        username: Plotly Cloud account email address.
            **Never sent to the browser** — stored server-side only.
        password: Plotly Cloud account password.
            **Never sent to the browser** — stored server-side only.
        client_secret: WorkOS client secret.
            Requires the ``cloud`` optional dependency
            (``pip install "dash-ai-analyst[cloud]"``).
            **Never sent to the browser** — stored server-side only.
        organization_id: WorkOS organization ID.  Required only when the
            account belongs to multiple organizations.
            **Never sent to the browser** — stored server-side only.
        oauth_client_id: WorkOS OAuth client ID.  Defaults to the production
            Plotly Cloud client ID.  Override to target a different environment
            (e.g. staging).
        api_base_url: Plotly Cloud API hostname (no scheme).  Defaults to the
            production hostname.  Override to target a different environment
            (e.g. ``"staging-cloud.plotly.host"``).

    Example::

        from dash_ai_analyst import AiAnalyst, PlotlyCloudConnector

        app.layout = AiAnalyst(
            connector=PlotlyCloudConnector(
                username="user@example.com",
                password="secret",
                client_secret="workos_client_secret",
            )
        )
    """

    def __init__(
        self,
        *,
        username: Optional[str] = None,
        password: Optional[str] = None,
        client_secret: Optional[str] = None,
        organization_id: Optional[str] = None,
        oauth_client_id: Optional[str] = None,
        api_base_url: Optional[str] = None,
    ) -> None:
        self._username = username
        self._password = password
        self._client_secret = client_secret
        self._organization_id = organization_id
        self._oauth_client_id = oauth_client_id
        self._api_base_url = api_base_url
        self._cached_token: Optional[dict] = None
        self._token_expires_at: float = 0.0
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    # Connector interface
    # ------------------------------------------------------------------

    def get_auth_init(self) -> Dict[str, Any]:
        if self._username and self._password and self._client_secret:
            return {"auth_mode": "developer"}
        if self._username or self._password or self._client_secret:
            logger.warning(
                "PlotlyCloudConnector: credentials are partially configured "
                "(username, password, and client_secret are all required). "
                "Falling back to viewer authentication."
            )
        return {}

    def get_stream_credentials(self, data: Dict[str, Any]) -> Tuple[str, str, Optional[str]]:
        token_data = self.get_developer_token()
        # Token lifecycle is managed server-side; refresh_token is not needed.
        return token_data["access_token"], "", None

    def resolve_access_token(self, data: Dict[str, Any]) -> str:
        return self.get_developer_token()["access_token"]

    def make_chat_model(
        self,
        access_token: str,
        model_id: str,
        token_refresher: Any,
        *,
        de_proxy_url: Optional[str] = None,
        team_id: Optional[str] = None,
    ) -> Any:
        from ._constants import API_BASE_URL
        from ._transport import make_plotly_cloud_chat_model

        return make_plotly_cloud_chat_model(
            access_token, self._api_base_url or API_BASE_URL, model_id, token_refresher, team_id=team_id
        )

    # ------------------------------------------------------------------
    # Developer token (WorkOS password grant)
    # ------------------------------------------------------------------

    def get_developer_token(self) -> dict:
        """Return a valid WorkOS access token, using the in-memory cache where possible.

        Raises:
            RuntimeError: If no credentials are configured.
            ImportError: If the ``workos`` package is not installed.
            ValueError: If ``client_secret`` or ``organization_id`` is missing.
        """
        if not (self._username and self._password and self._client_secret):
            raise RuntimeError("No developer credentials are configured.")

        with self._lock:
            if self._cached_token and time.time() < self._token_expires_at - 60:
                return self._cached_token

            try:
                from workos import WorkOSClient  # type: ignore[import]
            except ImportError as exc:
                raise ImportError(
                    "The 'workos' package is required for PlotlyCloudConnector. "
                    'Install it with: pip install "dash-ai-analyst[cloud]"'
                ) from exc

            from ._constants import OAUTH_CLIENT_ID

            workos_client = WorkOSClient(
                api_key=self._client_secret,
                client_id=self._oauth_client_id or OAUTH_CLIENT_ID,
            )

            try:
                auth_result = workos_client.user_management.authenticate_with_password(
                    email=self._username,
                    password=self._password,
                )
            except Exception as exc:
                error_details = exc.args[0] if exc.args else {}
                if (
                    isinstance(error_details, dict)
                    and error_details.get("code") == "organization_selection_required"
                ):
                    pending_token = error_details.get("pending_authentication_token")
                    organizations = error_details.get("organizations", [])
                    if not pending_token or not organizations:
                        raise

                    if not self._organization_id:
                        raise ValueError(
                            "This account belongs to multiple organizations. "
                            "Pass organization_id=... to PlotlyCloudConnector to select one."
                        )
                    org = next(
                        (o for o in organizations if o.get("id") == self._organization_id),
                        None,
                    )
                    if org is None:
                        raise ValueError(
                            f"organization_id {self._organization_id!r} was not found in "
                            "the list of organizations returned by WorkOS."
                        )
                    auth_result = workos_client.user_management.authenticate_with_organization_selection(
                        pending_authentication_token=pending_token,
                        organization_id=org["id"],
                    )
                else:
                    raise

            token_data = {
                "access_token": auth_result.access_token,
                "refresh_token": auth_result.refresh_token,
            }
            self._cached_token = token_data
            self._token_expires_at = _token_expiry(auth_result.access_token)
            logger.info("Plotly Cloud developer credentials authenticated successfully.")
            return token_data


class DashEnterpriseConnector(Connector):
    """Dash Enterprise (Keycloak) authentication connector.

    Authenticates viewers automatically using the developer's Keycloak
    credentials.  Viewers never see a sign-in screen — AI usage is billed to
    the developer's Dash Enterprise account.  No extra package required.

    Args:
        username: Dash Enterprise account username.
            **Never sent to the browser** — stored server-side only.
        password: Dash Enterprise account password.
            **Never sent to the browser** — stored server-side only.
        de_url: Dash Enterprise base URL, e.g. ``"https://my-de.example.com"``.
            **Never sent to the browser** — stored server-side only.

    Example::

        from dash_ai_analyst import AiAnalyst, DashEnterpriseConnector

        app.layout = AiAnalyst(
            connector=DashEnterpriseConnector(
                username="admin",
                password="secret",
                de_url="https://my-de.example.com",
            )
        )
    """

    def __init__(
        self,
        *,
        username: Optional[str] = None,
        password: Optional[str] = None,
        de_url: Optional[str] = None,
    ) -> None:
        self._username = username
        self._password = password
        self._de_url = de_url.rstrip("/") if de_url else None
        self._cached_token: Optional[dict] = None
        self._token_expires_at: float = 0.0
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    # Connector interface
    # ------------------------------------------------------------------

    def get_auth_init(self) -> Dict[str, Any]:
        if self._username and self._password and self._de_url:
            return {"auth_mode": "developer"}
        if self._username or self._password or self._de_url:
            logger.warning(
                "DashEnterpriseConnector: credentials are partially configured "
                "(username, password, and de_url are all required). "
                "Falling back to viewer authentication."
            )
        return {}

    def get_stream_credentials(self, data: Dict[str, Any]) -> Tuple[str, str, Optional[str]]:
        token_data = self.get_developer_token()
        # Token lifecycle is managed server-side; refresh_token is not needed.
        return token_data["access_token"], "", token_data.get("de_proxy_url")

    def resolve_access_token(self, data: Dict[str, Any]) -> str:
        return self.get_developer_token()["access_token"]

    def make_chat_model(
        self,
        access_token: str,
        model_id: str,
        token_refresher: Any,
        *,
        de_proxy_url: Optional[str] = None,
        team_id: Optional[str] = None,
    ) -> Any:
        from ._constants import API_BASE_URL
        from ._transport import make_de_chat_model, make_plotly_cloud_chat_model

        # de_proxy_url is always set by get_stream_credentials for developer mode.
        # The fallback handles the unlikely case of a direct make_chat_model call.
        proxy = de_proxy_url or (self._de_url + "/api/ai" if self._de_url else None)
        if proxy:
            return make_de_chat_model(access_token, proxy, model_id, token_refresher)
        # Fallback: no proxy URL available (misconfigured deployment)
        return make_plotly_cloud_chat_model(access_token, API_BASE_URL, model_id, token_refresher)

    # ------------------------------------------------------------------
    # Developer token (Keycloak ROPC)
    # ------------------------------------------------------------------

    def get_developer_token(self) -> dict:
        """Return a valid Keycloak access token, using the in-memory cache where possible.

        Raises:
            RuntimeError: If no credentials are configured.
        """
        if not (self._username and self._password and self._de_url):
            raise RuntimeError("No developer credentials are configured.")

        with self._lock:
            if self._cached_token and time.time() < self._token_expires_at - 60:
                return self._cached_token

            import httpx

            from ._constants import KEYCLOAK_CLIENT_ID, KEYCLOAK_SCOPE, USER_AGENT
            from ._oauth import _keycloak_token_url

            with httpx.Client() as client:
                response = client.post(
                    _keycloak_token_url(self._de_url),
                    data={
                        "client_id": KEYCLOAK_CLIENT_ID,
                        "grant_type": "password",
                        "username": self._username,
                        "password": self._password,
                        "scope": KEYCLOAK_SCOPE,
                    },
                    headers={
                        "Content-Type": "application/x-www-form-urlencoded",
                        "user-agent": USER_AGENT,
                    },
                )

            if response.status_code != 200:
                raise Exception(
                    f"Dash Enterprise authentication failed ({response.status_code}): "
                    f"{response.text[:200]}"
                )

            body = response.json()
            token_data = {
                "access_token": body["access_token"],
                "refresh_token": body.get("refresh_token", ""),
                "de_proxy_url": self._de_url + "/api/ai",
            }
            self._cached_token = token_data
            # Keycloak's expires_in is the fallback when the token has no exp.
            self._token_expires_at = _token_expiry(
                body["access_token"], body.get("expires_in")
            )
            logger.info("Dash Enterprise developer credentials authenticated successfully.")
            return token_data


# ---------------------------------------------------------------------------
# Module-level connector registry
# ---------------------------------------------------------------------------

_connector: Optional[Connector] = None

# True once the private OpenRouter endpoint has taken over.  It keeps
# set_connector from displacing the endpoint, which is the precedence
# get_connector used to apply on every call.
_private_endpoint = False


def init_connector() -> Connector:
    """Resolve the connector for this process and store it.

    Called once from :func:`~._hooks.install_hooks`, so request handling is
    left with a plain attribute read.

    The private OpenRouter endpoint wins over any registered connector.  It is
    imported here rather than at module level because it subclasses
    :class:`Connector`, and the import is guarded because released wheels
    leave the module out — an env var alone must not be able to turn the
    endpoint on in a deployed app.
    """
    global _connector, _private_endpoint

    try:
        from ._openrouter import _openrouter_connector_from_env
    except ImportError:
        private = None
    else:
        private = _openrouter_connector_from_env()

    _private_endpoint = private is not None
    _connector = private or _connector or ViewerCredentialConnector()
    return _connector


def set_connector(connector: Connector) -> None:
    """Store the active connector.  Called by :class:`~.AiAnalyst` at startup.

    Only one connector is supported per process.  If multiple ``AiAnalyst``
    instances are created with different connectors, the last call wins.
    Ignored while the private OpenRouter endpoint is active, so an app's own
    connector cannot route around it.
    """
    global _connector
    if _private_endpoint:
        return
    _connector = connector


def get_connector() -> Connector:
    """Return the active connector.

    Falls back to resolving it here for the cases that never reach
    :func:`install_hooks`, such as tests importing the package directly.
    """
    return _connector or init_connector()
