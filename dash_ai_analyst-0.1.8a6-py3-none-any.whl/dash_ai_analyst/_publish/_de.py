"""Publish artifacts to Dash Enterprise.

Handles creating a minimal Dash app directory, registering it on the DE
instance via GraphQL, and deploying via git push.  No external ``de_client``
library is required — all communication is done directly over HTTP (GraphQL)
and the system ``git`` binary.

After git push the frontend polls :func:`get_de_app_status` to track the
build and deployment lifecycle, mapping DE GraphQL states to the same status
vocabulary used by Plotly Cloud (BUILDING, STARTING, RUNNING, FAILED, …).
"""

import asyncio
import os
import shutil
import subprocess
import tempfile
from typing import Any, Dict, Optional
from urllib.parse import urlparse

import httpx

from ._app_code import build_app_py, build_procfile, build_requirements_txt, title_to_de_slug

# ---------------------------------------------------------------------------
# GraphQL query / mutation strings
# ---------------------------------------------------------------------------

_GQL_APP_EXISTS = """
query($slug: String!) {
    app(slug: $slug) {
        app_id
    }
}
"""

_GQL_APP_CREATE = """
mutation($app: AppInput!) {
    createOneApp(input: { app: $app }) {
        app_id
    }
}
"""

_GQL_APP_STATUS = """
query($slug: String!) {
    app(slug: $slug) {
        builds {
            status
            created_at
        }
        deployments {
            status
            process_type
            created_at
        }
    }
}
"""

# ---------------------------------------------------------------------------
# DE build/deployment status → Plotly-Cloud-style status mapping
# ---------------------------------------------------------------------------

# Build statuses reported by DE GraphQL
_BUILD_ACTIVE = {"pending", "queued", "building"}
_BUILD_FAILED = {"failed", "error", "cancelled"}

# Deployment statuses reported by DE GraphQL
_DEPLOY_ACTIVE = {"pending", "starting"}
_DEPLOY_FAILED = {"failed", "error"}


def _map_de_status(builds: list, deployments: list) -> str:
    """Translate DE build/deployment state lists to a frontend status string.

    Priority:
    1. Most-recent build is active   → ``BUILDING``
    2. Most-recent build has failed  → ``FAILED``
    3. Build succeeded, deployment active → ``STARTING``
    4. Build succeeded, deployment running → ``RUNNING``
    5. Build succeeded, deployment stopped/failed → ``STOPPED`` / ``FAILED``
    6. No builds yet (push just landed) → ``BUILDING``
    """
    if not builds:
        return "BUILDING"

    latest_build = max(builds, key=lambda b: b.get("created_at") or "")
    build_status = (latest_build.get("status") or "").lower()

    if build_status in _BUILD_ACTIVE:
        return "BUILDING"
    if build_status in _BUILD_FAILED:
        return "FAILED"

    # Build finished successfully — check deployment state.
    if not deployments:
        return "STARTING"

    web_deployments = [d for d in deployments if d.get("process_type") == "web"] or deployments
    latest_deploy = max(web_deployments, key=lambda d: d.get("created_at") or "")
    deploy_status = (latest_deploy.get("status") or "").lower()

    if deploy_status == "running":
        return "RUNNING"
    if deploy_status in _DEPLOY_ACTIVE:
        return "STARTING"
    if deploy_status in _DEPLOY_FAILED:
        return "FAILED"
    if deploy_status in {"stopped", "stopping"}:
        return "STOPPED"

    # Unknown deployment status — assume still starting.
    return "STARTING"


# ---------------------------------------------------------------------------
# GraphQL helper
# ---------------------------------------------------------------------------


async def _graphql(
    hostname: str,
    access_token: str,
    query: str,
    variables: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Execute a raw GraphQL request against the DE API.

    Args:
        hostname: DE instance host (and optional port), e.g. ``"my-de.example.com"``.
        access_token: Keycloak Bearer token.
        query: GraphQL query or mutation string.
        variables: Optional variable dict.

    Returns:
        The ``"data"`` field of the GraphQL response.

    Raises:
        httpx.HTTPStatusError: On non-2xx HTTP response.
        RuntimeError: If the response contains GraphQL errors.
    """
    async with httpx.AsyncClient() as client:
        response = await client.post(
            f"https://api-{hostname}/graphql",
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                "Authorization": f"Bearer {access_token}",
            },
            json={"query": query, "variables": variables or {}},
            timeout=15.0,
        )
    response.raise_for_status()
    body = response.json()
    if body.get("errors"):
        raise RuntimeError(f"GraphQL errors: {body['errors']}")
    return body.get("data", {})


# ---------------------------------------------------------------------------
# App lifecycle helpers
# ---------------------------------------------------------------------------


async def _ensure_app_exists(
    hostname: str,
    access_token: str,
    slug: str,
    title: str,
) -> None:
    """Create the DE app if it does not already exist.

    Args:
        hostname: DE instance hostname.
        access_token: Keycloak Bearer token.
        slug: Target app slug (e.g. ``"dai-revenue-by-region"``).
        title: Human-readable app title used when creating the app.
    """
    data = await _graphql(hostname, access_token, _GQL_APP_EXISTS, {"slug": slug})
    if data.get("app"):
        return  # already exists — reuse it
    await _graphql(
        hostname,
        access_token,
        _GQL_APP_CREATE,
        {"app": {"slug": slug, "title": title}},
    )


# ---------------------------------------------------------------------------
# Git push
# ---------------------------------------------------------------------------


def _git_push(hostname: str, access_token: str, slug: str, app_dir: str) -> None:
    """Initialise a temporary git repo from *app_dir* and force-push to DE.

    Uses ``git -c http.extraHeader="Authorization: Bearer <token>"`` so that
    Keycloak Bearer authentication is passed on the push without embedding
    credentials in the remote URL.

    Args:
        hostname: DE instance hostname (and optional port).
        access_token: Keycloak Bearer token.  Must not contain shell
            metacharacters — Keycloak JWTs are base64url-encoded so this is
            always safe in practice.
        slug: App slug used in the remote URL ``/GIT/{slug}``.
        app_dir: Path to the directory containing the app files to deploy.

    Raises:
        RuntimeError: If any git command exits with a non-zero return code.
        FileNotFoundError: If the ``git`` binary is not found on PATH.
    """
    if not shutil.which("git"):
        raise FileNotFoundError(
            "git is not installed or not on PATH — required for Dash Enterprise publishing"
        )

    remote_url = f"https://{hostname}/GIT/{slug}"
    # Bearer token is injected via http.extraHeader; this is safe for JWTs
    # because they are base64url-encoded (characters: A-Z a-z 0-9 - _ .).
    auth_flag = f'-c http.extraHeader="Authorization: Bearer {access_token}"'

    temp_dir = tempfile.mkdtemp()
    try:
        shutil.copytree(app_dir, temp_dir, dirs_exist_ok=True)

        commands = [
            "git init -q",
            'git config user.email "<>"',
            'git config user.name "Dash AI Analyst"',
            "git config http.postBuffer 2097152000",
            "git symbolic-ref HEAD refs/heads/main",
            f"git remote add origin {remote_url}",
            "git add .",
            'git commit -qm "Published from Dash AI Analyst"',
            f"git {auth_flag} push --force origin main",
        ]

        for cmd in commands:
            result = subprocess.run(
                cmd,
                shell=True,
                cwd=temp_dir,
                capture_output=True,
                text=True,
            )
            if result.returncode != 0:
                raise RuntimeError(
                    f"git command failed: {cmd!r}\n{result.stderr.strip()}"
                )
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


# ---------------------------------------------------------------------------
# Public entry points
# ---------------------------------------------------------------------------


async def get_de_app_status(
    slug: str,
    access_token: str,
    de_url: str,
) -> Dict[str, Any]:
    """Poll Dash Enterprise for the current build/deployment status of an app.

    Queries the DE GraphQL ``app`` endpoint for the most recent build and
    deployment, then maps the result to the Plotly-Cloud-compatible status
    vocabulary the frontend already understands (BUILDING, STARTING, RUNNING,
    FAILED, STOPPED).

    Args:
        slug: App slug returned by :func:`publish_to_de` (``app_id`` field).
        access_token: Viewer's Keycloak Bearer token.
        de_url: Full DE base URL, e.g. ``"https://my-de.example.com"``.

    Returns:
        ``{"result": {"status": "RUNNING"}}`` or ``{"error": "..."}``
    """
    normalized = de_url if de_url.startswith("http") else f"https://{de_url}"
    hostname = urlparse(normalized).netloc
    if not hostname:
        return {"error": f"Could not parse hostname from DE URL: {de_url!r}"}

    try:
        data = await _graphql(hostname, access_token, _GQL_APP_STATUS, {"slug": slug})
    except Exception as exc:
        return {"error": str(exc)}

    app = data.get("app")
    if not app:
        return {"error": f"App {slug!r} not found on Dash Enterprise"}

    status = _map_de_status(app.get("builds") or [], app.get("deployments") or [])
    return {"result": {"status": status}}


async def publish_to_de(
    access_token: str,
    de_url: str,
    artifact_type: str,
    serialized: Dict[str, Any],
    title: str,
) -> Dict[str, Any]:
    """Deploy a chart or table artifact to Dash Enterprise as a minimal Dash app.

    Flow:
    1. Extract the DE hostname from *de_url*.
    2. Generate app files (``app.py``, ``requirements.txt``, ``Procfile``).
    3. Ensure the app exists on DE (create via GraphQL if needed).
    4. Push the app files via git.
    5. Return the URL, app slug (as ``app_id``), and initial status so the
       frontend can start polling :func:`get_de_app_status`.

    Args:
        access_token: Viewer's Keycloak Bearer token.
        de_url: Full DE base URL, e.g. ``"https://my-de.example.com"`` or
            ``"https://my-de.example.com/my_app"``.  Only the scheme+host
            portion is used for API/git calls.
        artifact_type: ``"figure"`` or ``"table"``.
        serialized: Artifact serialized dict from the frontend.
        title: Human-readable app title.

    Returns:
        ``{"result": {"url": ..., "app_id": slug, "status": "BUILDING"}}``
        on success, or ``{"error": "..."}`` on failure.
    """
    # Extract bare hostname (with optional port) from the DE URL.
    normalized = de_url if de_url.startswith("http") else f"https://{de_url}"
    parsed = urlparse(normalized)
    hostname = parsed.netloc  # e.g. "my-de.example.com" or "my-de.example.com:8080"
    if not hostname:
        return {"error": f"Could not parse hostname from DE URL: {de_url!r}"}

    slug = title_to_de_slug(title)

    try:
        app_py = build_app_py(artifact_type, serialized, title)
    except ValueError as exc:
        return {"error": str(exc)}

    app_dir = tempfile.mkdtemp()
    try:
        with open(os.path.join(app_dir, "app.py"), "w") as fh:
            fh.write(app_py)
        with open(os.path.join(app_dir, "requirements.txt"), "w") as fh:
            fh.write(build_requirements_txt())
        with open(os.path.join(app_dir, "Procfile"), "w") as fh:
            fh.write(build_procfile())

        # Register the app on DE (no-op if it already exists).
        try:
            await _ensure_app_exists(hostname, access_token, slug, title)
        except Exception as exc:
            return {"error": f"Failed to register app on Dash Enterprise: {exc}"}

        # Deploy via git push (blocking subprocess, run in thread pool).
        try:
            await asyncio.to_thread(_git_push, hostname, access_token, slug, app_dir)
        except (RuntimeError, FileNotFoundError) as exc:
            return {"error": f"Deployment failed: {exc}"}

    finally:
        shutil.rmtree(app_dir, ignore_errors=True)

    app_url = f"https://{hostname}/{slug}"
    return {"result": {"url": app_url, "app_id": slug, "status": "BUILDING"}}
