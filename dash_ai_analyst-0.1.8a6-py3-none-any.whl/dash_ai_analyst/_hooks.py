"""Dash hooks for the AI analyst plugin — Layer 3: zero-config auto-wiring.

This module is discovered automatically by Dash via the ``dash_hooks``
entry point declared in ``pyproject.toml``.  When Dash starts it imports
this module, which calls :func:`install_hooks` at module load time.

``install_hooks`` wires the plugin into the running Dash app by registering:

* A ``@dash.hooks.layout()`` decorator that appends the chat UI to the
  app's existing layout (only when an ``AiAnalyst`` container
  is not already present) and triggers auto-discovery of dataframes.
* The CSS and JS assets via ``dash.hooks.stylesheet`` / ``dash.hooks.script``.
* Two ``@dash.hooks.route`` endpoints that delegate to the plugin's handlers.

All of that is Flask-only, so it is registered from a ``@dash.hooks.setup()``
check once the app — and therefore its backend — exists.  On an ASGI backend
nothing is registered and the app serves its own layout untouched.
"""

import os
import logging
import traceback
import dash
from flask import abort, current_app as flask_current_app, send_from_directory

from ._connector import init_connector
from ._routes import RouteHandler
from ._constants import ROUTE_RPC, ROUTE_STREAM
from ._registry import auto_discover_data

_DOCS_DIR = os.path.join(os.path.dirname(__file__), "_docs")


def _find_chat_container(layout):
    """Return the AiAnalyst component if present in the layout tree, else None."""
    if isinstance(layout, list):
        for item in layout:
            found = _find_chat_container(item)
            if found is not None:
                return found
        return None
    if getattr(layout, "_type", None) == "AiAnalyst" and getattr(layout, "_namespace", None) == "dash_ai_analyst":
        return layout
    children = getattr(layout, "children", None)
    if children is not None:
        return _find_chat_container(children)
    return None


def _find_inline_chat_container(layout):
    """Return an inline AiAnalyst component if present in the layout tree."""
    if isinstance(layout, list):
        for item in layout:
            found = _find_inline_chat_container(item)
            if found is not None:
                return found
        return None
    if (
        getattr(layout, "_type", None) == "AiAnalyst"
        and getattr(layout, "_namespace", None) == "dash_ai_analyst"
        and getattr(layout, "inline", False)
    ):
        return layout
    children = getattr(layout, "children", None)
    if children is not None:
        return _find_inline_chat_container(children)
    return None


def _register_bundle_script() -> None:
    """Register the component bundle in Dash's script hooks."""
    dash.hooks.script([{
        "relative_package_path": "dash_ai_analyst.min.js",
        "namespace": "dash_ai_analyst",
    }])


def _register_bundle_stylesheet() -> None:
    """Register the plugin stylesheet in Dash's stylesheet hooks."""
    dash.hooks.stylesheet([{
        "relative_package_path": "dash_ai_analyst.css",
        "namespace": "dash_ai_analyst",
    }])


def _append_chat_container(layout, *, error_traceback=None):
    """Attach error info to existing AiAnalyst, else append floating fallback."""
    inline_container = _find_inline_chat_container(layout)
    if inline_container is not None:
        inline_container.error_traceback = error_traceback
        return layout

    existing = _find_chat_container(layout)
    if existing is not None:
        existing.error_traceback = error_traceback
        return layout

    from .AiAnalyst import AiAnalyst as AiAnalystComponent

    container = AiAnalystComponent(inline=False, error_traceback=error_traceback)
    if isinstance(layout, list):
        return layout + [container]
    from dash import html
    return html.Div([layout, container])


def _install_error_fallback(tb_str: str) -> None:
    """Install a minimal error UI fallback when normal hook install fails."""
    try:
        _register_bundle_script()
    except Exception:
        logging.exception("Failed to register bundle script for error UI")
        return

    try:
        @dash.hooks.layout()
        def add_error_ui(layout):
            try:
                return _append_chat_container(layout, error_traceback=tb_str)
            except Exception:
                logging.exception("Failed to inject error UI from fallback layout hook")
                return layout
    except Exception:
        logging.exception("Failed to register error-UI layout hook")


_EXPERIMENTAL_WARNING = (
    "WARNING: Plotly Studio Embedded is experimental software. "
    "Developer APIs and behaviour may change without notice."
)

logger = logging.getLogger(__name__)

# The plugin is WSGI/Flask-only: the route handlers use ``flask.request`` and
# ``flask.Response``, and session scoping reads ``flask.session``.  Dash also
# supports ASGI backends (FastAPI, Quart); on those the plugin registers
# nothing at all, so the app serves its own layout as if we were not installed.
_SUPPORTED_BACKEND = "flask"

# True once the plugin has been installed, which happens at most once per
# process even if several Dash apps are constructed.
_installed = False

_UNSUPPORTED_BACKEND_WARNING = (
    "Plotly Studio Embedded requires a Flask (WSGI) Dash app but this app uses "
    "the '%s' (ASGI) backend, which is not supported yet. The chat UI, its assets "
    "and its endpoints are not registered; the app renders its own layout."
)


def _unsupported_backend(app) -> "str | None":
    """Return the app's backend name if it is not Flask, else ``None``.

    Dash versions predating pluggable backends expose no ``server_type`` and
    are always Flask, so a missing value means supported.
    """
    server_type = getattr(getattr(app, "backend", None), "server_type", _SUPPORTED_BACKEND)
    return None if str(server_type).lower() == _SUPPORTED_BACKEND else server_type


def install_hooks() -> None:
    """Arrange for the plugin to be installed into the Dash app.

    Called automatically at import time via the ``dash_hooks`` entry point.
    Only a ``setup`` hook is registered here: the plugin's assets, layout hook
    and routes are Flask-only, and the backend is not known until Dash builds
    the app.  :func:`_install_plugin` does the real work once it is.
    """
    logger.warning(_EXPERIMENTAL_WARNING)
    init_connector()
    try:
        @dash.hooks.setup()
        def check_backend(app):
            """Install the plugin unless the app runs on an unsupported backend.

            Runs during ``Dash.__init__``: early enough to register assets and
            routes (Dash collects route hooks afterwards), and long before the
            first request.
            """
            global _installed
            if _installed:
                return
            unsupported = _unsupported_backend(app)
            if unsupported:
                logger.warning(_UNSUPPORTED_BACKEND_WARNING, unsupported)
                return
            _installed = True
            _install_plugin()
    except Exception:
        logging.exception("Failed to register the backend-check hook")
        _install_error_fallback(traceback.format_exc())


def _install_plugin() -> None:
    """Wire the plugin into the Dash app.

    Creates a single :class:`~._routes.RouteHandler` instance shared across
    all requests (stateless design) and registers the layout hook, assets,
    and routes.
    """
    try:
        import nest_asyncio

        # Allow nested event-loop calls from Flask's synchronous request threads
        nest_asyncio.apply()

        plugin = RouteHandler()

        # Register the component bundle so Dash includes it in every page's script tags
        _register_bundle_script()
        _register_bundle_stylesheet()

        @dash.hooks.layout()
        def add_chat_ui(layout):
            """Append the chat container to the app's top-level layout.

            Skips injection when an ``AiAnalyst`` component is already present.
            Also triggers auto-discovery of global DataFrames defined in the app.
            Discovery runs only once per process (idempotent).

            This serve-time call is the sole discovery trigger.  It must not
            run earlier (e.g. at ``AiAnalyst`` construction): on deployment
            platforms the constructor executes while the generated wrapper
            (Plotly Cloud's ``_plotly_wsgi``) is still mid-import, so the
            entrypoint module would be unreachable and the once-per-process
            flag latched before any of its DataFrames could be seen.
            """
            try:
                _layout = layout
                existing = _find_chat_container(_layout)
                if not (existing is not None and getattr(existing, "skip_global_data", False)):
                    auto_discover_data()

                # Always inject the hidden Plotly loader so charts render even when
                # the app has no dcc.Graph of its own.  Also inject a config element
                # so the JS can read debug-only settings (e.g. docs_url) synchronously
                # without waiting for an async RPC response.
                from dash import dcc, html as _html
                extras = [dcc.Graph(
                    id="_dash-ai-analyst-plotly-loader",
                    style={"display": "none"},
                    figure={},
                )]
                if flask_current_app.debug and os.path.isdir(_DOCS_DIR):
                    extras.append(_html.Div(
                        id="_dash-ai-analyst-config",
                        **{"data-docs-url": "/_dash_ai_analyst/docs/"},
                        style={"display": "none"},
                    ))
                if isinstance(_layout, list):
                    _layout = _layout + extras
                else:
                    _layout = _html.Div([_layout] + extras)

                if existing is not None:
                    return _layout  # explicit component already in place

                from .AiAnalyst import AiAnalyst as AiAnalystComponent
                container = AiAnalystComponent(inline=False)

                if isinstance(_layout, list):
                    return _layout + [container]
                from dash import html
                return html.Div([_layout, container])

            except Exception:
                tb = traceback.format_exc()
                logging.exception("Failed to add chat UI in layout hook")
                try:
                    return _append_chat_container(layout, error_traceback=tb)
                except Exception:
                    logging.exception("Failed to inject error UI")
                    return layout

        @dash.hooks.route(ROUTE_RPC, methods=["POST"])
        def rpc():
            """Auth and metadata RPC endpoint."""
            return plugin._rpc_handler()

        @dash.hooks.route(ROUTE_STREAM, methods=["POST"])
        def stream():
            """SSE streaming chat endpoint."""
            return plugin._stream_handler()

        # Docs routes — only served when the Flask app runs in debug mode.
        # Access at /_dash_ai_analyst/docs/ while running with debug=True.
        # Uses dash.hooks.route (not dash.get_app().server) so registration is
        # deferred until after Dash finishes constructing the app.

        @dash.hooks.route("/_dash_ai_analyst/docs/", methods=["GET"])
        def _docs_index():
            if not flask_current_app.debug:
                abort(404)
            if not os.path.isdir(_DOCS_DIR):
                abort(404)
            return send_from_directory(_DOCS_DIR, "index.html")

        @dash.hooks.route("/_dash_ai_analyst/docs/<path:path>", methods=["GET"])
        def _docs_file(path: str):
            if not flask_current_app.debug:
                abort(404)
            if not os.path.isdir(_DOCS_DIR):
                abort(404)
            # MkDocs generates directories with index.html inside (e.g.
            # installation/ → installation/index.html).  Serve that file when
            # the path resolves to a directory rather than a file.
            full = os.path.join(_DOCS_DIR, path)
            if os.path.isdir(full):
                path = path.rstrip("/") + "/index.html"
            return send_from_directory(_DOCS_DIR, path)

    except Exception:
        tb = traceback.format_exc()
        logging.exception("Failed to install hooks")
        _install_error_fallback(tb)

# Auto-install when Dash discovers and imports this module via the entry point
install_hooks()
