"""Flask route handlers for the AI analyst plugin backend.

Owns the two HTTP endpoints (RPC + SSE stream) and the OAuth device-
authorization helpers.  This is an internal module — app developers interact
with the frontend :class:`~.AiAnalyst` Dash component, not this code.
"""

import asyncio
import inspect
import json
import logging
import os
import secrets
import sys
import time
from typing import Any, Dict, Optional

import flask
import httpx

from ._agent import run_agent_streamed
from ._connector import get_connector
from ._constants import (
    API_BASE_URL,
    APP_DOMAIN,
    DEFAULT_MODEL,
    OAUTH_CLIENT_ID,
    USER_AGENT,
    WORKOS_LOGOUT_URL,
)
from ._oauth import KeycloakClient, OAuthClient
from ._publish import get_cloud_app_status, get_de_app_status, publish_to_cloud, publish_to_de
from ._registry import get_all_metadata, get_session_scope
from ._secrets import SecretsMap, retrieve_secrets
from ._transport import TokenRefresher

logger = logging.getLogger(__name__)

_SSE_KEEPALIVE_INTERVAL = 15  # seconds between keepalive comments

# Upper bound, in seconds, on how long a single stream may keep its gunicorn
# worker alive.  Unset (the default) means no cap: the worker stays alive for
# as long as the stream keeps producing output.
_HEARTBEAT_CAP_ENV_VAR = "DASH_AI_ANALYST_HEARTBEAT_CAP_SECONDS"


def _heartbeat_cap_seconds() -> Optional[float]:
    """Return the configured heartbeat cap, or ``None`` for no cap.

    Read per stream rather than at import so the value can be changed without
    rebuilding the app.  Non-numeric or non-positive values disable the cap.
    """
    raw = os.environ.get(_HEARTBEAT_CAP_ENV_VAR, "").strip()
    if not raw:
        return None
    try:
        cap = float(raw)
    except ValueError:
        logger.warning(
            "Ignoring %s=%r — expected a number of seconds.", _HEARTBEAT_CAP_ENV_VAR, raw
        )
        return None
    return cap if cap > 0 else None


def _find_gunicorn_worker() -> Any:
    """Return the gunicorn worker handling this request, or ``None``.

    Gunicorn keeps no registry of workers and unlinks the heartbeat file
    (``WorkerTmp`` holds only an fd), so the live ``Worker`` object is the only
    route to ``notify()``.  It is reachable because the WSGI response is
    iterated inside ``Worker.handle_request``, whose frame holds ``self`` — so
    walking out from the response generator finds it.  Returns ``None`` under
    any other server, and under gunicorn worker classes that iterate responses
    off the worker's own stack.

    ``sys.modules`` is consulted instead of importing gunicorn so this stays a
    no-op (and adds no dependency) when the app runs under something else.
    """
    base = sys.modules.get("gunicorn.workers.base")
    worker_cls = getattr(base, "Worker", None)
    if worker_cls is None:
        return None

    frame = inspect.currentframe()
    try:
        frame = frame.f_back if frame is not None else None
        while frame is not None:
            candidate = frame.f_locals.get("self")
            if isinstance(candidate, worker_cls):
                return candidate
            frame = frame.f_back
    finally:
        del frame
    return None


class _WorkerHeartbeat:
    """Keeps gunicorn's arbiter from reaping a worker mid-stream.

    Gunicorn's ``--timeout`` is a worker liveness heartbeat, not an idle
    timeout.  The sync worker only calls ``notify()`` between requests, so a
    chat turn that outlives the timeout gets SIGABRT-ed part-way through the
    response and the viewer sees a truncated stream.  Beating once per emitted
    SSE chunk keeps the worker marked alive for exactly as long as the stream
    is actually producing output; a wedged event loop stops emitting, stops
    beating, and is still reaped.

    Beating on *every* chunk rather than only on keepalives matters: a turn
    that emits real events faster than ``keepalive_interval`` never produces a
    keepalive, and would otherwise go unheartbeaten.
    """

    def __init__(self, worker: Any, cap_seconds: Optional[float]) -> None:
        self._worker = worker
        self._cap = cap_seconds
        self._started = time.monotonic()
        self._enabled = True

    @property
    def interval(self) -> float:
        """Keepalive interval that also satisfies the arbiter's deadline.

        ``Worker.timeout`` is already half of ``--timeout`` (the arbiter halves
        it when spawning), so beating once per ``Worker.timeout`` seconds is
        gunicorn's own intended cadence.  A falsy value means ``--timeout 0``,
        i.e. reaping is disabled.
        """
        worker_timeout = getattr(self._worker, "timeout", None) or 0
        if worker_timeout <= 0:
            return _SSE_KEEPALIVE_INTERVAL
        return max(1.0, min(float(_SSE_KEEPALIVE_INTERVAL), float(worker_timeout)))

    def beat(self) -> None:
        if not self._enabled:
            return

        elapsed = time.monotonic() - self._started
        if self._cap is not None and elapsed > self._cap:
            logger.warning(
                "Stream exceeded the %.0fs heartbeat cap (%s); no longer holding the "
                "gunicorn worker open. The worker may be restarted mid-response.",
                self._cap,
                _HEARTBEAT_CAP_ENV_VAR,
            )
            self._enabled = False
            return

        try:
            self._worker.notify()
        except Exception:
            # Private gunicorn API — degrade to the previous behaviour rather
            # than breaking the stream if it ever changes.
            logger.debug("gunicorn heartbeat failed; disabling it", exc_info=True)
            self._enabled = False


def _make_heartbeat() -> Optional[_WorkerHeartbeat]:
    """Build a heartbeat for this request, or ``None`` when not under gunicorn.

    Must be called from the stack that iterates the WSGI response — see
    :func:`_find_gunicorn_worker`.
    """
    worker = _find_gunicorn_worker()
    if worker is None:
        return None
    return _WorkerHeartbeat(worker, _heartbeat_cap_seconds())


def _ensure_secret_key() -> None:
    """Auto-set a Flask secret key if none is configured.

    Flask sessions (used by :func:`~._registry.get_session_scope`) require a
    secret key to sign cookies.  This helper is called at the start of each
    request handler so the key is set before any session access, without
    needing the app object at import time.

    The auto-generated key lives in the worker's memory: it is regenerated
    on every process restart and is not shared between gunicorn workers.
    That breaks any feature relying on a stable per-viewer session scope
    (user-scoped ``register_data``, the secret resolver, conversation
    history) across workers or restarts, so we warn loudly and recommend
    the developer set their own key.
    """
    app = flask.current_app._get_current_object()
    if not app.secret_key:
        app.secret_key = secrets.token_hex(32)
        logger.warning(
            "Flask `secret_key` is not configured; Plotly Studio Embedded generated an "
            "ephemeral key for this worker. Sessions will not survive process "
            "restarts and will not be consistent across multiple gunicorn "
            "workers, which breaks user-scoped data registration and the "
            "secret resolver under multi-worker deployments. Set a stable "
            "value via `app.server.secret_key = ...`."
        )


def _resolve_access_token(data: Dict[str, Any]) -> str:
    """Return the access token for a request.

    Delegates to the active connector so developer connectors can inject
    server-side tokens without the browser ever holding them.
    """
    return get_connector().resolve_access_token(data)


def _run_sync(coro: Any) -> Any:
    """Run an async coroutine synchronously inside Flask's request thread.

    Flask request handlers are synchronous, but the OAuth and RPC helpers are
    ``async``.  ``nest_asyncio`` (applied in ``_hooks.py``) patches the running
    event loop so that ``loop.run_until_complete`` can be called re-entrantly
    from within a loop that is already running.
    """
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    return loop.run_until_complete(coro)


async def _sse_event_stream(agent_gen, keepalive_interval: float = _SSE_KEEPALIVE_INTERVAL):
    """Yield SSE-encoded strings from an agent event generator, with keepalives.

    Emits ``: keepalive`` comments while the next event is still being produced
    so idle proxies/load-balancers don't drop the connection.

    Crucially, the in-flight ``__anext__()`` is held as a task and polled with
    :func:`asyncio.wait` rather than wrapped in :func:`asyncio.wait_for`.
    ``wait_for`` cancels its awaitable on timeout, which would throw
    ``CancelledError`` into the running LLM/tool call, abort the agent, and end
    the stream with no ``done``/``error`` event — the browser reports that as
    "Connection interrupted." This only bit when a single step (a slow model
    turn or a heavy query) ran longer than ``keepalive_interval``, so it looked
    intermittent. :func:`asyncio.wait` leaves the task running across keepalives.
    """
    step = None
    while True:
        if step is None:
            step = asyncio.ensure_future(agent_gen.__anext__())
        done_set, _ = await asyncio.wait({step}, timeout=keepalive_interval)
        if not done_set:
            # Step still running — keep the connection warm without cancelling
            # the in-progress work.
            yield ": keepalive\n\n"
            continue
        try:
            event = step.result()
        except StopAsyncIteration:
            break
        except Exception as exc:
            # Unhandled exception escaped the agent generator — surface it as an
            # error SSE event so the browser always gets feedback.
            logger.exception("Unhandled exception in agent generator")
            error_payload = json.dumps(
                {"error": "agent_error", "message": str(exc)},
                default=str,
            )
            yield f"event: error\ndata: {error_payload}\n\n"
            break
        finally:
            step = None
        event_type = event.get("event", "message")
        event_data = json.dumps(event.get("data", {}), default=str)
        yield f"event: {event_type}\ndata: {event_data}\n\n"


class RouteHandler:
    """Internal handler that wires together the two Flask endpoints.

    Combines the LangChain agent streaming loop and the OAuth device-
    authorization flow.  Instantiated once by :func:`~._hooks.install_hooks`
    and shared across all requests — stateless by design (per-request state
    lives in the browser).
    """

    def __init__(self) -> None:
        self._oauth_client = OAuthClient(OAUTH_CLIENT_ID)
        self._keycloak_client = KeycloakClient()

    # ------------------------------------------------------------------
    # Flask route handlers
    # ------------------------------------------------------------------

    def _rpc_handler(self) -> flask.Response:
        """Handle ``POST /_dash_ai_analyst`` — auth and metadata operations.

        Reads a JSON body with an ``"operation"`` field and dispatches to the
        appropriate async helper via :func:`_run_sync`.  Returns a JSON
        response with either a ``"result"`` or an ``"error"`` key.
        """
        _ensure_secret_key()
        data = flask.request.get_json()
        result = _run_sync(self._handle_operation(data))
        return flask.jsonify(result)

    def _stream_handler(self) -> flask.Response:
        """Handle ``POST /_dash_ai_analyst_stream`` — streaming chat via SSE.

        Reads a JSON body containing ``access_token``, ``messages``
        (LLM-format conversation
        history), ``message`` (the new user turn), and optionally
        ``stored_outputs`` (serialised artifacts from the previous turn).
        Returns a ``text/event-stream`` response that flushes
        :class:`~._agent.StreamEvent` objects as they arrive.
        """
        _ensure_secret_key()
        data = flask.request.get_json()

        connector = get_connector()
        try:
            access_token, refresh_token, de_proxy_url = connector.get_stream_credentials(data)
        except Exception as exc:
            return flask.jsonify({"error": f"Authentication failed: {exc}"}), 401

        # Derived from the signed session cookie only.  The scope key can't
        # be trusted unsigned: a value supplied by the caller would let anyone
        # read another viewer's datasets and secrets by naming their scope.
        scope_key: Optional[str] = get_session_scope()
        messages = data.get("messages", [])
        user_message: str = data.get("message", "")
        stored_outputs = data.get("stored_outputs") or []
        # de_url is only used for the viewer token-refresh path below.
        # Developer connectors send an empty refresh_token, so that branch is never taken.
        de_url: Optional[str] = data.get("de_url") or None
        team_id: Optional[str] = data.get("team_id") or None
        system_prompt: Optional[str] = data.get("system_prompt") or None
        system_prompt_appendix: Optional[str] = data.get("system_prompt_appendix") or None
        # TODO: the frontend no longer sends this; kept for when get_app_layout is revisited.
        app_state: Optional[Any] = data.get("app_state") or None
        resolved_secrets: SecretsMap = retrieve_secrets(scope_key)
        oauth_client = self._oauth_client
        keycloak_client = self._keycloak_client

        if de_url and refresh_token:
            # DE users: refresh via Keycloak, not WorkOS
            async def _do_refresh() -> Optional[str]:
                try:
                    result = await keycloak_client.refresh_access_token(de_url, refresh_token)
                    return result.get("access_token")
                except Exception:
                    return None
        elif refresh_token:
            # Plotly Cloud users: refresh via WorkOS OAuth
            async def _do_refresh() -> Optional[str]:  # type: ignore[misc]
                try:
                    result = await oauth_client.refresh_access_token(refresh_token)
                    return result.get("access_token")
                except Exception:
                    return None
        else:
            _do_refresh = None  # type: ignore[assignment]

        token_refresher = TokenRefresher(
            access_token,
            refresh_callback=_do_refresh,
        )

        chat_model = connector.make_chat_model(
            access_token,
            DEFAULT_MODEL,
            token_refresher,
            de_proxy_url=de_proxy_url,
            team_id=team_id,
        )

        def generate():
            """Synchronous generator that drives the async agent stream."""
            # Resolved here, not in `_stream_handler`, because the worker is
            # found by walking the stack that iterates this response.
            heartbeat = _make_heartbeat()
            keepalive_interval = heartbeat.interval if heartbeat else _SSE_KEEPALIVE_INTERVAL

            def async_generate():
                agent_gen = run_agent_streamed(
                    model=chat_model,
                    messages=messages,
                    user_message=user_message,
                    stored_outputs=stored_outputs,
                    scope=scope_key,
                    token_refresher=token_refresher,
                    system_prompt=system_prompt,
                    system_prompt_appendix=system_prompt_appendix,
                    app_state=app_state,
                    secrets=resolved_secrets,
                )
                return _sse_event_stream(agent_gen, keepalive_interval)

            try:
                loop = asyncio.get_event_loop()
            except RuntimeError:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)

            gen = async_generate()
            while True:
                try:
                    chunk = loop.run_until_complete(gen.__anext__())
                    if heartbeat is not None:
                        heartbeat.beat()
                    yield chunk
                except StopAsyncIteration:
                    break
                except Exception as exc:
                    # Async machinery itself failed — yield a final error event so
                    # the browser receives something instead of a silent connection reset.
                    logger.exception("Unexpected error in SSE stream outer loop")
                    error_payload = json.dumps(
                        {"error": "agent_error", "message": str(exc)},
                        default=str,
                    )
                    yield f"event: error\ndata: {error_payload}\n\n"
                    break

        return flask.Response(
            generate(),
            mimetype="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "X-Accel-Buffering": "no",  # Disable nginx buffering for SSE
            },
        )

    # ------------------------------------------------------------------
    # Auth operation helpers (called from _rpc_handler via _handle_operation)
    # ------------------------------------------------------------------

    async def _handle_operation(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Dispatch a JSON-RPC-style operation to the appropriate handler."""
        operation = data.get("operation")

        try:
            if operation == "initialize":
                return await self._initialize()
            elif operation == "authenticate":
                return await self._authenticate()
            elif operation == "auth_poll":
                return await self._auth_poll(data.get("device_code", ""))
            elif operation == "refresh_token":
                return await self._refresh_token(data.get("refresh_token", ""))
            elif operation == "list_teams":
                return await self._list_teams(data.get("access_token", ""))
            elif operation == "publish_artifact":
                return await self._publish_artifact(data)
            elif operation == "get_app_status":
                return await self._get_app_status(
                    data.get("app_id", ""),
                    _resolve_access_token(data),
                    data.get("de_url") or None,
                )
            elif operation == "de_device_auth":
                return await self._de_device_auth(data.get("de_url", ""))
            elif operation == "de_device_poll":
                return await self._de_device_poll(data.get("de_url", ""), data.get("device_code", ""))
            elif operation == "de_refresh":
                return await self._de_refresh(data.get("de_url", ""), data.get("refresh_token", ""))
            else:
                return {"error": f"Unknown operation: {operation}"}
        except Exception as e:
            return {"error": str(e)}

    async def _initialize(self) -> Dict[str, Any]:
        """Return dataframe metadata and client-side config for bootstrapping.

        When developer credentials are configured via
        :class:`~.AiAnalyst`, this also authenticates server-side and
        returns a ``developer_token`` so the browser can skip the sign-in
        flow entirely.
        """
        scope_key = get_session_scope()
        metadata = get_all_metadata(scope=scope_key)
        result: Dict[str, Any] = {
            "datasets": metadata,
            "config": {
                "logout_url": WORKOS_LOGOUT_URL,
                # DE auth is always available — the viewer supplies their own de_url
                "supports_dash_enterprise": True,
            },
        }

        result.update(get_connector().get_auth_init())

        return {"result": result}

    async def _authenticate(self) -> Dict[str, Any]:
        """Start the OAuth device-authorization flow."""
        try:
            auth_data = await self._oauth_client.request_device_authorization()
            return {
                "result": {
                    "device_code": auth_data["device_code"],
                    "user_code": auth_data["user_code"],
                    "verification_uri": auth_data["verification_uri"],
                    "verification_uri_complete": auth_data.get(
                        "verification_uri_complete"
                    ),
                    "expires_in": auth_data["expires_in"],
                    "interval": auth_data.get("interval", 5),
                }
            }
        except Exception as e:
            return {"error": f"Authentication failed: {str(e)}"}

    async def _auth_poll(self, device_code: str) -> Dict[str, Any]:
        """Poll WorkOS to check whether the viewer has completed sign-in."""
        if not device_code:
            return {"error": "device_code is required"}

        try:
            status_code, response = await self._oauth_client.check_authentication_status(
                device_code
            )

            if status_code == 200:
                return {
                    "result": {
                        "authenticated": True,
                        "access_token": response["access_token"],
                        "refresh_token": response["refresh_token"],
                    }
                }
            else:
                error = response.get("error", "unknown_error")
                if error == "authorization_pending":
                    return {"result": {"authenticated": False, "pending": True}}
                elif error == "slow_down":
                    return {"result": {"authenticated": False, "slow_down": True}}
                else:
                    return {"error": error}
        except Exception as e:
            return {"error": str(e)}

    async def _list_teams(self, access_token: str) -> Dict[str, Any]:
        """Return the Plotly Cloud teams the authenticated viewer belongs to."""
        if not access_token:
            return {"result": {"teams": []}}
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"https://{API_BASE_URL}/api/teams",
                    headers={
                        "Authorization": f"Bearer {access_token}",
                        "User-Agent": USER_AGENT,
                    },
                    timeout=10.0,
                )
            if response.status_code != 200:
                return {"error": f"Failed to fetch teams ({response.status_code})"}
            data = response.json()
            teams = [
                {
                    "id": m["team"]["id"],
                    "name": m["team"]["name"],
                    "description": m["team"].get("description"),
                    "role": m.get("role"),
                }
                for m in data.get("teams", [])
            ]
            return {"result": {"teams": teams}}
        except Exception as exc:
            return {"error": str(exc)}

    async def _publish_artifact(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Publish a chart or table as a minimal Dash app.

        Routes to Plotly Cloud or Dash Enterprise depending on whether
        ``de_url`` is present in the request payload.

        Accepted fields:
        - ``type``: ``"figure"`` or ``"table"``
        - ``serialized``: artifact serialized dict from the frontend
        - ``title``: human-readable app title
        - ``access_token``: viewer's Bearer token
        - ``de_url`` *(optional)*: when present, publish to Dash Enterprise
          instead of Plotly Cloud
        """
        access_token: str = _resolve_access_token(data)
        artifact_type: str = data.get("type", "")
        serialized: Dict[str, Any] = data.get("serialized", {})
        title: str = data.get("title", "Shared from Dash AI Analyst")
        de_url: Optional[str] = data.get("de_url") or None
        team_id: Optional[str] = data.get("team_id") or None

        if de_url:
            return await publish_to_de(
                access_token=access_token,
                de_url=de_url,
                artifact_type=artifact_type,
                serialized=serialized,
                title=title,
            )

        return await publish_to_cloud(
            access_token=access_token,
            artifact_type=artifact_type,
            serialized=serialized,
            title=title,
            api_base_url=API_BASE_URL,
            app_domain=APP_DOMAIN,
            team_id=team_id,
        )

    async def _get_app_status(
        self, app_id: str, access_token: str, de_url: Optional[str] = None
    ) -> Dict[str, Any]:
        """Poll deployment status — routes to DE or Plotly Cloud based on ``de_url``."""
        if de_url:
            return await get_de_app_status(
                slug=app_id,
                access_token=access_token,
                de_url=de_url,
            )
        return await get_cloud_app_status(
            app_id=app_id,
            access_token=access_token,
            api_base_url=API_BASE_URL,
        )

    async def _refresh_token(self, refresh_token: str) -> Dict[str, Any]:
        """Exchange a refresh token for a new access/refresh token pair."""
        if not refresh_token:
            return {"error": "refresh_token is required"}

        try:
            token_data = await self._oauth_client.refresh_access_token(refresh_token)
            return {
                "result": {
                    "access_token": token_data["access_token"],
                    "refresh_token": token_data["refresh_token"],
                }
            }
        except Exception as e:
            return {"error": str(e)}

    # ------------------------------------------------------------------
    # Dash Enterprise (Keycloak) auth operation helpers
    # ------------------------------------------------------------------

    async def _de_device_auth(self, de_url: str) -> Dict[str, Any]:
        """Start the Keycloak device authorization flow for a viewer-supplied DE instance."""
        if not de_url:
            return {"error": "de_url is required"}
        try:
            response = await self._keycloak_client.start_device_flow(de_url)
            return {
                "result": {
                    "device_code": response["device_code"],
                    "user_code": response["user_code"],
                    "verification_uri": response.get("verification_uri_complete") or response["verification_uri"],
                    "expires_in": response.get("expires_in", 300),
                    "interval": response.get("interval", 5),
                }
            }
        except Exception as e:
            return {"error": str(e)}

    async def _de_device_poll(self, de_url: str, device_code: str) -> Dict[str, Any]:
        """Poll for completion of the Keycloak device flow.

        Returns tokens on success, ``{"result": {"pending": true}}`` while
        waiting, or an error on failure.
        """
        if not de_url:
            return {"error": "de_url is required"}
        if not device_code:
            return {"error": "device_code is required"}
        try:
            token_data = await self._keycloak_client.poll_device_token(de_url, device_code)
            if token_data is None:
                return {"result": {"pending": True}}
            return {
                "result": {
                    "access_token": token_data["access_token"],
                    "refresh_token": token_data.get("refresh_token", ""),
                }
            }
        except Exception as e:
            return {"error": str(e)}

    async def _de_refresh(self, de_url: str, refresh_token: str) -> Dict[str, Any]:
        """Refresh a Keycloak access token."""
        if not de_url:
            return {"error": "de_url is required"}
        if not refresh_token:
            return {"error": "refresh_token is required"}
        try:
            token_data = await self._keycloak_client.refresh_access_token(de_url, refresh_token)
            return {
                "result": {
                    "access_token": token_data["access_token"],
                    "refresh_token": token_data.get("refresh_token", refresh_token),
                }
            }
        except Exception as e:
            return {"error": str(e)}
