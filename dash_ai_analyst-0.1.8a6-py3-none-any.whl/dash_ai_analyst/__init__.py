"""Dash AI Analyst — AI-powered chat for Dash app viewers.

Adds a floating chat interface to any Dash application so that viewers
can explore registered dataframes through natural language, run SQL
queries, and generate Plotly charts — all charged to the viewer's own
Plotly Cloud account.

**Drop-in component usage** (recommended)

Place :class:`AiAnalyst` anywhere in your ``app.layout``::

    from dash_ai_analyst import AiAnalyst

    app.layout = html.Div([
        # ... your existing content ...
        AiAnalyst(),
    ])

**Zero-config usage** (no layout change required)

The plugin auto-wires itself via a ``dash_hooks`` entry point declared in
``pyproject.toml``.  No import is required; Dash discovers and loads the
hook automatically at startup.  Just register your dataframes and the chat
UI appears::

    from dash_ai_analyst import register_data

    register_data(sales_df, "sales", description="Monthly sales data")
    register_data(customers_df, "customers", description="Customer CRM data")
"""

from ._connector import Connector, DashEnterpriseConnector, PlotlyCloudConnector, ViewerCredentialConnector
from ._registry import (
    clear_data,
    get_registered_data,
    register_data,
    unregister_data,
)
from ._secrets import SecretStr, set_secret_resolver
from ._sources import Source
from ._style import ChatStyle
from .AiAnalyst import AiAnalyst

__version__ = "0.1.0"

__all__ = [
    "AiAnalyst",
    "Connector",
    "ViewerCredentialConnector",
    "PlotlyCloudConnector",
    "DashEnterpriseConnector",
    "ChatStyle",
    "Source",
    "register_data",
    "unregister_data",
    "get_registered_data",
    "clear_data",
    "set_secret_resolver",
    "SecretStr",
    "__version__",
]
