"""Serialization helpers for persisting stored outputs to the browser."""

from typing import Any, Dict, List, Optional

from ._context import StoredOutput


def serialize_stored_outputs(outputs: Dict[str, StoredOutput]) -> List[Dict[str, Any]]:
    """Convert in-memory stored outputs to a JSON-safe list for the browser.

    Each entry keeps only the *handle*, *type*, and *serialized* fields —
    the live Python objects (figure dict, DataFrame) are excluded.

    Figure and table handles carry their full serialized content (chart dict
    or display rows) since those are needed for rendering in the browser.
    """
    return [
        {"handle": o.handle, "type": o.type, "serialized": o.serialized}
        for o in outputs.values()
    ]


def deserialize_stored_outputs(data: Optional[List[Dict[str, Any]]]) -> Dict[str, StoredOutput]:
    """Reconstruct a :class:`StoredOutput` dict from browser-persisted JSON.

    Figures and display tables are reconstructed from their ``serialized``
    content.
    """
    import pandas as pd

    result: Dict[str, StoredOutput] = {}
    for item in (data or []):
        handle = item.get("handle", "")
        t = item.get("type", "")
        serialized = item.get("serialized", {})

        if t == "table":
            rows = serialized.get("rows", [])
            data_obj: Any = pd.DataFrame(rows)
        else:
            data_obj = serialized.get("chart", serialized)

        result[handle] = StoredOutput(
            handle=handle,
            type=t,
            data=data_obj,
            serialized=serialized,
        )
    return result
