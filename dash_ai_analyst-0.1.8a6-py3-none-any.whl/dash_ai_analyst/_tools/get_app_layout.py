"""get_app_layout tool — retrieve the current Dash application layout as JSON."""

import json
from typing import Any

from langchain.tools import ToolRuntime, tool

from ._context import AgentContext

_LIST_TRUNCATE = 10

# Props that add no semantic value for the LLM but can be very large.
_SKIP_PROPS = frozenset({"style", "className", "class_name"})


def _serialize(obj: Any) -> Any:
    """Recursively convert Dash components, Plotly figures, and other objects to
    plain dicts/lists suitable for JSON serialisation."""
    # Dash components and Plotly Figure objects both expose to_plotly_json()
    if hasattr(obj, "to_plotly_json"):
        return _serialize(obj.to_plotly_json())
    if isinstance(obj, dict):
        return {k: _serialize(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_serialize(item) for item in obj]
    # Scalar — verify JSON-serialisability; fall back to string representation
    try:
        json.dumps(obj)
        return obj
    except (TypeError, ValueError):
        return str(obj)


def _truncate_lists(obj: Any, limit: int = _LIST_TRUNCATE, _key: str | None = None) -> Any:
    """Truncate every list in the structure to *limit* items.

    This keeps figure data arrays (which can be tens of thousands of points)
    at a manageable size while preserving the overall shape of the layout.

    ``children`` arrays are structural (component hierarchy) and are never
    truncated — only data arrays such as ``figure.data`` or trace ``x``/``y``
    are limited.  Without this exemption, dashboards with more than *limit*
    sibling components would silently lose components from the layout tree.
    """
    if isinstance(obj, list):
        if _key == "children":
            return [_truncate_lists(item, limit, _key=None) for item in obj]
        return [_truncate_lists(item, limit, _key=None) for item in obj[:limit]]
    if isinstance(obj, dict):
        return {k: _truncate_lists(v, limit, _key=k) for k, v in obj.items()}
    return obj


_STRING_TRUNCATE = 100


def _truncate_strings(obj: Any, limit: int = _STRING_TRUNCATE) -> Any:
    """Truncate any string value longer than *limit* characters.

    This catches base64-encoded images, long data URIs, and other large
    string blobs that add no useful information for the LLM.
    """
    if isinstance(obj, str):
        return obj if len(obj) <= limit else obj[:limit] + f"…[{len(obj)} chars]"
    if isinstance(obj, list):
        return [_truncate_strings(item, limit) for item in obj]
    if isinstance(obj, dict):
        return {k: _truncate_strings(v, limit) for k, v in obj.items()}
    return obj


def _strip_props_keys(obj: Any) -> Any:
    """Recursively strip visual-only keys from every ``props`` dict.

    ``style``, ``className``, and similar keys add hundreds of tokens per
    component without helping the model understand layout structure or data.
    """
    if isinstance(obj, list):
        return [_strip_props_keys(item) for item in obj]
    if isinstance(obj, dict):
        if "props" in obj and isinstance(obj["props"], dict):
            cleaned_props = {
                k: _strip_props_keys(v)
                for k, v in obj["props"].items()
                if k not in _SKIP_PROPS
            }
            return {
                k: (cleaned_props if k == "props" else _strip_props_keys(v))
                for k, v in obj.items()
            }
        return {k: _strip_props_keys(v) for k, v in obj.items()}
    return obj


# TODO: excluded from _DATA_TOOLS until revisited
@tool
def get_app_layout(
    runtime: ToolRuntime[AgentContext] = None,  # type: ignore[assignment]
) -> str:
    """Retrieve the current Dash application layout as JSON.

    Returns the full component tree — every panel, chart, table, and
    control visible to the viewer — including the exact Plotly figure
    objects (traces, layout, axes, annotations, etc.) embedded in
    ``dcc.Graph`` components.  Data arrays inside figures are truncated
    to 10 items and visual-only props (style, className) are omitted to
    keep the response concise.

    The layout reflects the viewer's **live** state: figures and
    components updated by callbacks (e.g. filter selections, tab
    switches) are returned as the viewer currently sees them, not the
    initial server-rendered state.

    Use this tool to understand what the dashboard currently shows:
    which charts are present, what data they contain, how axes are
    labelled, and how components are structured.  Combine with the
    data tools to answer questions that bridge the visual layout and
    the underlying datasets.
    """
    ctx = runtime.context

    # Prefer the live frontend state captured at request time (reflects
    # callback-driven updates the viewer has made).
    if ctx.app_state is not None:
        cleaned = _strip_props_keys(ctx.app_state)
        truncated = _truncate_lists(cleaned)
        truncated = _truncate_strings(truncated)
        return json.dumps(truncated)

    # Fall back to evaluating the Python-side layout (initial state only).
    try:
        import dash
        app = dash.get_app()
    except Exception as exc:
        return json.dumps({"error": f"Could not access Dash app: {exc}"})

    layout = app.layout
    if callable(layout):
        try:
            layout = layout()
        except Exception as exc:
            return json.dumps({"error": f"Could not evaluate layout: {exc}"})

    serialized = _serialize(layout)
    cleaned = _strip_props_keys(serialized)
    truncated = _truncate_lists(cleaned)
    truncated = _truncate_strings(truncated)
    return json.dumps(truncated)
