"""Custom exceptions for the AI analyst plugin."""


class AiAnalystError(Exception):
    """Base exception for AI analyst errors."""

    def __init__(self, message: str, details: str = ""):
        self.message = message
        self.details = details
        super().__init__(f"{message}: {details}" if details else message)


class AuthenticationError(AiAnalystError):
    """Authentication-related errors."""

    pass


class TokenError(AuthenticationError):
    """Token-related errors (expired, invalid, missing)."""

    pass
