"""Publish artifacts to Plotly Cloud.

Handles creating and deploying a minimal Dash app as a ZIP to the Plotly
Cloud ``POST /api/app`` endpoint, and polling its deployment status via
``GET /api/app/{app_id}``.
"""

import io
import json
import zipfile
from typing import Any, Dict, Optional

import httpx

from .._constants import USER_AGENT
from ._app_code import build_app_py, build_pyproject_toml


async def publish_to_cloud(
    access_token: str,
    artifact_type: str,
    serialized: Dict[str, Any],
    title: str,
    api_base_url: str,
    app_domain: str,
    team_id: Optional[str] = None,
) -> Dict[str, Any]:
    """Deploy a chart or table artifact to Plotly Cloud as a minimal Dash app.

    Generates a self-contained ``app.py`` + ``pyproject.toml``, packages them
    into a ZIP, and POSTs to ``POST /api/app``.  Returns the deployment result
    including the live URL and ``app_id`` for status polling.

    Args:
        access_token: Viewer's Plotly Cloud Bearer token.
        artifact_type: ``"figure"`` or ``"table"``.
        serialized: Artifact serialized dict from the frontend.
        title: Human-readable app title.
        api_base_url: Plotly Cloud host, e.g. ``"cloud.plotly.com"``.
        app_domain: Domain suffix for live app URLs, e.g. ``"plotly.app"``.
        team_id: Optional team UUID to publish under.

    Returns:
        ``{"result": {"url": ..., "app_id": ..., "status": ...}}`` on success,
        or ``{"error": "..."}`` on failure.
    """
    try:
        app_py = build_app_py(artifact_type, serialized, title)
    except ValueError as exc:
        return {"error": str(exc)}

    zip_buf = io.BytesIO()
    with zipfile.ZipFile(zip_buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("app.py", app_py)
        zf.writestr("pyproject.toml", build_pyproject_toml())
    zip_bytes = zip_buf.getvalue()

    config: Dict[str, Any] = {
        "name": title[:64],
        "pythonVersion": "3.13",
        "description": f"Shared from Dash AI Analyst: {title}"[:200],
        "isViewPrivate": "public",
    }
    if team_id:
        config["teamId"] = team_id
    app_config = json.dumps(config)

    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"https://{api_base_url}/api/app",
                headers={
                    "Authorization": f"Bearer {access_token}",
                    "User-Agent": USER_AGENT,
                },
                files={"file": ("project.zip", zip_bytes, "application/zip")},
                data={"json": app_config},
                timeout=60.0,
            )
    except Exception as exc:
        return {"error": f"Publish error: {exc}"}

    if response.status_code not in (200, 201):
        return {"error": f"Publish failed ({response.status_code}): {response.text[:200]}"}

    result = response.json()
    slug: str = result.get("app_url") or ""
    if not slug:
        return {"error": "No URL returned from Plotly Cloud"}

    url = f"https://{slug}.{app_domain}"
    return {"result": {"url": url, "app_id": result.get("id"), "status": result.get("status")}}


async def get_cloud_app_status(
    app_id: str,
    access_token: str,
    api_base_url: str,
) -> Dict[str, Any]:
    """Poll ``GET /api/app/{app_id}`` and return the current deployment status.

    Args:
        app_id: The app's UUID returned by :func:`publish_to_cloud`.
        access_token: Viewer's Plotly Cloud Bearer token.
        api_base_url: Plotly Cloud host, e.g. ``"cloud.plotly.com"``.

    Returns:
        ``{"result": {"status": "RUNNING"}}`` or ``{"error": "..."}``
    """
    if not app_id:
        return {"error": "app_id is required"}
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"https://{api_base_url}/api/app/{app_id}",
                headers={
                    "Authorization": f"Bearer {access_token}",
                    "User-Agent": USER_AGENT,
                },
                timeout=10.0,
            )
        if response.status_code != 200:
            return {"error": f"Status check failed ({response.status_code})"}
        result = response.json()
        return {"result": {"status": result.get("status")}}
    except Exception as exc:
        return {"error": str(exc)}
