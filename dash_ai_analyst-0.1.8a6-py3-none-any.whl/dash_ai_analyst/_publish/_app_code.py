"""Shared app code generation for published chart/table artifacts.

Both the Plotly Cloud and Dash Enterprise publishers use these helpers to
produce the minimal self-contained Dash application that wraps a chart or
table artifact.
"""

import json
import re
from typing import Any, Dict


def build_app_py(artifact_type: str, serialized: Dict[str, Any], title: str) -> str:
    """Return app.py source code for the given artifact type.

    Args:
        artifact_type: ``"figure"`` or ``"table"``.
        serialized: The artifact's serialized dict from the frontend.
        title: Human-readable title for the app heading.

    Returns:
        Complete ``app.py`` source as a string.

    Raises:
        ValueError: If *artifact_type* is not recognised.
    """
    title_repr = repr(title)

    if artifact_type == "figure":
        chart_json_repr = repr(json.dumps(serialized.get("chart", {})))
        return (
            "import json\n"
            "import dash\n"
            "from dash import dcc, html\n"
            "app = dash.Dash(__name__)\n"
            "server = app.server\n"
            f"FIGURE = json.loads({chart_json_repr})\n"
            f"TITLE = {title_repr}\n"
            "app.layout = html.Div([\n"
            '    html.H2(TITLE, style={"textAlign": "center", "fontFamily": "sans-serif", "padding": "16px"}),\n'
            '    dcc.Graph(figure=FIGURE, style={"height": "600px"}),\n'
            '], style={"maxWidth": "1200px", "margin": "0 auto"})\n'
            'if __name__ == "__main__":\n'
            "    app.run(debug=False)\n"
        )

    if artifact_type == "table":
        rows_repr = repr(serialized.get("rows", []))
        columns_repr = repr(serialized.get("columns", []))
        return (
            "import dash\n"
            "from dash import dash_table, html\n"
            "app = dash.Dash(__name__)\n"
            "server = app.server\n"
            f"ROWS = {rows_repr}\n"
            f"COLUMNS = {columns_repr}\n"
            f"TITLE = {title_repr}\n"
            "app.layout = html.Div([\n"
            '    html.H2(TITLE, style={"textAlign": "center", "fontFamily": "sans-serif", "padding": "16px"}),\n'
            "    dash_table.DataTable(\n"
            "        data=ROWS,\n"
            '        columns=[{"name": c, "id": c} for c in COLUMNS],\n'
            "        page_size=50,\n"
            '        style_table={"overflowX": "auto"},\n'
            '        style_cell={"padding": "6px 12px", "fontSize": "13px"},\n'
            '        style_header={"fontWeight": "bold", "background": "#f8f9fa"},\n'
            "    ),\n"
            '], style={"maxWidth": "1400px", "margin": "0 auto", "padding": "20px"})\n'
            'if __name__ == "__main__":\n'
            "    app.run(debug=False)\n"
        )

    raise ValueError(f"Unsupported artifact type: {artifact_type!r}")


def build_pyproject_toml() -> str:
    """Return a minimal pyproject.toml for Plotly Cloud deployment."""
    return (
        "[project]\n"
        'name = "shared-app"\n'
        'version = "0.1.0"\n'
        'requires-python = ">=3.9"\n'
        "dependencies = [\n"
        '    "dash",\n'
        '    "plotly",\n'
        "]\n"
    )


def build_requirements_txt() -> str:
    """Return a requirements.txt suitable for Dash Enterprise deployment."""
    return "dash\nplotly\ngunicorn\n"


def build_procfile() -> str:
    """Return a Procfile for Dash Enterprise deployment (gunicorn server)."""
    return "web: gunicorn app:server --workers 4 --bind 0.0.0.0:$PORT\n"


def title_to_de_slug(title: str) -> str:
    """Convert an arbitrary title to a valid Dash Enterprise app slug.

    Rules (matching DE requirements):
    - Lowercase alphanumeric and hyphens only
    - No leading/trailing hyphens
    - Maximum 50 characters total
    - Prefixed with ``dai-`` to namespace AI-analyst-shared apps

    Args:
        title: The chart/table title entered by the user.

    Returns:
        A valid DE app slug, e.g. ``"dai-revenue-by-region"``.
    """
    base = re.sub(r"[^a-z0-9-]", "", re.sub(r"[\s_]+", "-", title.lower()))
    base = re.sub(r"-+", "-", base).strip("-")
    prefix = "dai-"
    max_base_len = 50 - len(prefix)
    return prefix + (base[:max_base_len] if base else "chart")
