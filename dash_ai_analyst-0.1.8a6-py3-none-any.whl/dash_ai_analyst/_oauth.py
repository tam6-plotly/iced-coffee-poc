"""OAuth client implementation for viewer authentication using WorkOS CLI Auth.

Viewers authenticate with Plotly Cloud so that AI usage is charged to their account,
not the app developer's account.
"""

import asyncio
import base64
import json
import logging
from typing import Any, Dict, Optional, Tuple, Union

import httpx
from typing_extensions import TypedDict

logger = logging.getLogger(__name__)

from ._constants import (
    DEFAULT_AUTH_PROVIDER,
    KEYCLOAK_CLIENT_ID,
    KEYCLOAK_GRANT_DEVICE,
    KEYCLOAK_GRANT_REFRESH,
    KEYCLOAK_REALM,
    KEYCLOAK_SCOPE,
    USER_AGENT,
    WORKOS_API_BASE_URL,
    WORKOS_ENDPOINTS,
)
from .exceptions import (
    AuthenticationError,
    TokenError,
)


class AuthTokenResponse(TypedDict):
    """Response from successful OAuth authentication."""

    access_token: str
    refresh_token: str
    token_type: str
    expires_in: int


class AuthErrorResponse(TypedDict):
    """Response from failed OAuth authentication."""

    error: str
    error_description: Optional[str]


AuthResponse = Union[AuthTokenResponse, AuthErrorResponse]


def get_exp_from_jwt(token: str) -> Optional[int]:
    """Return a JWT's ``exp`` claim as a Unix timestamp, or ``None``.

    Access tokens carry their own expiry; the token endpoints do not reliably
    report one.  The signature is not verified: the claim only decides when to
    refresh, and the LLM gateway remains the authority on token validity.
    """
    if not token or not isinstance(token, str):
        return None

    parts = token.split(".")
    if len(parts) != 3:
        return None

    try:
        # JWT segments are base64url with the padding stripped.
        payload = parts[1]
        claims = json.loads(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))
    except Exception:
        logger.debug("Could not decode JWT payload segment.")
        return None

    exp = claims.get("exp") if isinstance(claims, dict) else None
    return int(exp) if isinstance(exp, (int, float)) else None


class OAuthClient:
    """OAuth client for WorkOS CLI Auth using device authorization flow.

    Unlike the developer chat extension, this client does NOT persist credentials
    to disk. Credentials are managed per-session in the browser/frontend.
    This ensures viewers authenticate fresh each time and usage is properly attributed.
    """

    def __init__(self, client_id: str):
        self.client_id = client_id

    async def request_device_authorization(self, provider: str = DEFAULT_AUTH_PROVIDER) -> dict:
        """Request device authorization from WorkOS CLI Auth.

        Returns device_code and user_code for the viewer to complete authentication.
        """
        if not self.client_id:
            raise AuthenticationError("client_id is required")

        device_auth_data = {
            "client_id": self.client_id,
            "provider": provider,
        }

        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{WORKOS_API_BASE_URL}{WORKOS_ENDPOINTS['DEVICE_AUTHORIZE']}",
                data=device_auth_data,
                headers={"Content-Type": "application/x-www-form-urlencoded", "user-agent": USER_AGENT},
            )

            if response.status_code != 200:
                raise AuthenticationError("Device authorization failed", response.text)

            return response.json()

    async def check_authentication_status(
        self,
        device_code: str,
        client: Optional[httpx.AsyncClient] = None,
    ) -> Tuple[int, AuthResponse]:
        """Check authentication status.

        Args:
            device_code: The device code from device authorization
            client: Optional httpx client to use

        Returns:
            Tuple of (status_code, response_data)
        """
        token_data = {
            "client_id": self.client_id,
            "device_code": device_code,
            "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
        }

        if client:
            response = await client.post(
                f"{WORKOS_API_BASE_URL}{WORKOS_ENDPOINTS['AUTHENTICATE']}",
                data=token_data,
                headers={"Content-Type": "application/x-www-form-urlencoded", "user-agent": USER_AGENT},
            )
        else:
            async with httpx.AsyncClient() as new_client:
                response = await new_client.post(
                    f"{WORKOS_API_BASE_URL}{WORKOS_ENDPOINTS['AUTHENTICATE']}",
                    data=token_data,
                    headers={"Content-Type": "application/x-www-form-urlencoded", "user-agent": USER_AGENT},
                )

        return response.status_code, response.json()

    async def poll_for_authentication(
        self, device_code: str, interval: int = 5, timeout: int = 300
    ) -> AuthTokenResponse:
        """Poll for authentication completion with exponential backoff."""
        start_time = asyncio.get_event_loop().time()
        current_interval = interval
        max_interval = 30

        async with httpx.AsyncClient() as client:
            while asyncio.get_event_loop().time() - start_time < timeout:
                status_code, response_data = await self.check_authentication_status(device_code, client)

                if status_code == 200:
                    return response_data  # type: ignore

                error = response_data.get("error", "unknown_error")

                if error == "authorization_pending":
                    await asyncio.sleep(current_interval)
                    current_interval = min(current_interval * 1.5, max_interval)
                    continue
                elif error == "slow_down":
                    current_interval = min(current_interval * 2, max_interval)
                    await asyncio.sleep(current_interval)
                    continue
                elif error == "expired_token":
                    raise TokenError("Device code expired. Please try again.")
                elif error == "access_denied":
                    raise AuthenticationError("Access denied by user.")
                else:
                    raise AuthenticationError("Authentication failed", error)

        raise TokenError("Authentication timed out. Please try again.")

    async def refresh_access_token(self, refresh_token: str) -> AuthTokenResponse:
        """Refresh the access token using the refresh token.

        Args:
            refresh_token: The refresh token to use

        Returns:
            New token response with updated tokens

        Raises:
            TokenError: If refresh fails
        """
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{WORKOS_API_BASE_URL}{WORKOS_ENDPOINTS['REFRESH_TOKEN']}",
                data={
                    "client_id": self.client_id,
                    "grant_type": "refresh_token",
                    "refresh_token": refresh_token,
                },
                headers={"Content-Type": "application/x-www-form-urlencoded", "user-agent": USER_AGENT},
            )

            if response.status_code == 200:
                return response.json()
            else:
                raise TokenError("Token refresh failed", response.text)


# ---------------------------------------------------------------------------
# Keycloak client (Dash Enterprise auth)
# ---------------------------------------------------------------------------

def _keycloak_host(de_url: str) -> str:
    """Extract the bare hostname from a DE URL."""
    host = de_url.strip()
    if host.startswith("http://") or host.startswith("https://"):
        from urllib.parse import urlparse
        host = urlparse(host).hostname or host
    return host


def _keycloak_device_url(de_url: str) -> str:
    return f"https://auth-{_keycloak_host(de_url)}/auth/realms/{KEYCLOAK_REALM}/protocol/openid-connect/auth/device"


def _keycloak_token_url(de_url: str) -> str:
    return f"https://auth-{_keycloak_host(de_url)}/auth/realms/{KEYCLOAK_REALM}/protocol/openid-connect/token"


class KeycloakClient:
    """OAuth client for Dash Enterprise using the Keycloak device authorization flow.

    The device flow lets users authenticate by visiting a URL and entering a
    short code — no browser popup or redirect required.
    """

    async def start_device_flow(self, de_url: str) -> dict:
        """Start the device authorization flow against a DE Keycloak instance.

        Args:
            de_url: Dash Enterprise hostname (e.g. ``"my-de.example.com"``).

        Returns:
            Dict with ``device_code``, ``user_code``, ``verification_uri``,
            ``verification_uri_complete``, ``expires_in``, and ``interval``.

        Raises:
            AuthenticationError: If the request fails.
        """
        async with httpx.AsyncClient() as client:
            response = await client.post(
                _keycloak_device_url(de_url),
                data={"client_id": KEYCLOAK_CLIENT_ID, "scope": KEYCLOAK_SCOPE},
                headers={"Content-Type": "application/x-www-form-urlencoded", "user-agent": USER_AGENT},
            )
        if response.status_code == 200:
            return response.json()
        raise AuthenticationError("Device authorization failed", response.text)

    async def poll_device_token(self, de_url: str, device_code: str) -> Optional[dict]:
        """Poll for a device authorization token.

        Args:
            de_url: Dash Enterprise hostname.
            device_code: The device code from :meth:`start_device_flow`.

        Returns:
            Token dict on success, or ``None`` if authorization is still pending.

        Raises:
            TokenError: If polling fails for any reason other than
                ``authorization_pending``.
        """
        async with httpx.AsyncClient() as client:
            response = await client.post(
                _keycloak_token_url(de_url),
                data={
                    "client_id": KEYCLOAK_CLIENT_ID,
                    "grant_type": KEYCLOAK_GRANT_DEVICE,
                    "device_code": device_code,
                },
                headers={"Content-Type": "application/x-www-form-urlencoded", "user-agent": USER_AGENT},
            )
        body = response.json()
        if response.status_code == 200 and "access_token" in body:
            return body
        if body.get("error") == "authorization_pending":
            return None
        raise TokenError(f"Device token poll failed: {body.get('error', 'unknown')}", body.get("error_description", ""))

    async def refresh_access_token(self, de_url: str, refresh_token: str) -> dict:
        """Refresh a Keycloak access token.

        Args:
            de_url: Dash Enterprise hostname.
            refresh_token: The refresh token to use.

        Returns:
            New token dict.

        Raises:
            TokenError: If the refresh fails.
        """
        async with httpx.AsyncClient() as client:
            response = await client.post(
                _keycloak_token_url(de_url),
                data={
                    "client_id": KEYCLOAK_CLIENT_ID,
                    "grant_type": KEYCLOAK_GRANT_REFRESH,
                    "refresh_token": refresh_token,
                },
                headers={"Content-Type": "application/x-www-form-urlencoded", "user-agent": USER_AGENT},
            )
        if response.status_code == 200:
            return response.json()
        raise TokenError("Token refresh failed", response.text)
