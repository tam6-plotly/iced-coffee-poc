"""display_table tool — present a SQL query result as a formatted table."""

import json
from typing import Any, Dict, Optional

from langchain.tools import ToolRuntime, tool

from .._constants import MAX_ROWS, PREVIEW_ROWS
from ._context import AgentContext, StoredOutput, _new_handle, _store
from ._db import df_to_json_safe, execute_query


@tool
def display_table(
    query: str,
    title: Optional[str] = None,
    runtime: ToolRuntime[AgentContext] = None,  # type: ignore[assignment]
) -> str:
    """Display a SQL query result as a formatted data table in the chat.

    Args:
        query: SQL query to run.
        title: Optional heading shown above the table.
    """
    ctx = runtime.context
    df = execute_query(query, ctx.scope, ctx.secrets)
    total_rows = len(df)

    if total_rows > MAX_ROWS:
        raise ValueError(
            f"Query returned {total_rows:,} rows, which exceeds the {MAX_ROWS:,}-row limit. "
            "Please refine your query — add a WHERE clause, GROUP BY aggregation, or LIMIT."
        )

    preview_df = df.head(PREVIEW_ROWS)
    rows = df_to_json_safe(preview_df)
    columns = list(df.columns)

    table_handle = _new_handle("tbl")
    serialized: Dict[str, Any] = {
        "query": query,
        "title": title or "Query Result",
        "columns": columns,
        "rows": rows,
        "row_count": total_rows,
    }
    _store(ctx, StoredOutput(
        handle=table_handle,
        type="table",
        data=preview_df,
        serialized=serialized,
    ))

    return json.dumps({
        "handle": table_handle,
        "type": "table",
        "row_count": total_rows,
        "columns": columns,
    })
