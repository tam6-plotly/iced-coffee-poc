"""Dash component wrapper for AiAnalyst."""

from dash.development.base_component import Component, _explicitize_args

from ._style import ChatStyle


class AiAnalyst(Component):
    """AI-powered chat component for Dash app viewers.

    Drop this into any ``app.layout`` — routes and assets are registered
    automatically by the ``dash_hooks`` entry point.  No ``init_app()`` call
    is needed.

    When the hook fires it checks whether an ``AiAnalyst`` container is already
    present in the layout; if so, it skips auto-injection so the chat UI is
    never duplicated.

    Keyword arguments:

    - id (string; optional):
        HTML id for the container element.  Defaults to
        ``"_dash-ai-analyst-container"``.

    - inline (boolean; default True):
        When True, renders the chat as an embedded page component instead
        of a floating modal.  The chat is immediately visible without the
        user needing to click a button.

    - show_fullscreen_toggle (boolean; default True):
        When True, shows a header control (to the left of the close button
        in floating mode) that expands the chat to fill the viewport or
        restores the previous size. The same control is available for
        inline (embedded) chat when set to True.

    - show_pdf_export (boolean; default True):
        When True, shows a header control in a session that opens the report
        builder — a two-pane screen where the viewer picks which questions,
        answers, charts and tables belong in a PDF, edits the title and any
        text, and saves the result through the browser's print dialog.

    - skip_global_data (boolean; default False):
        When True, disables auto-discovery of global DataFrames.  Only
        datasets explicitly registered via ``register_data()`` will be
        available to the AI.

    - system_prompt (string; optional):
        When provided, replaces the auto-generated system prompt entirely.
        The dataset list, tool descriptions, and all default instructions
        are omitted.  Use this when you need full control over the AI's
        behaviour and persona.

    - system_prompt_appendix (string; optional):
        When provided, this text is appended to the effective system prompt
        (whether that is the auto-generated prompt or a ``system_prompt``
        override).  Use this to add domain context, a company name, or
        extra instructions without rewriting the full prompt.

    - error_traceback (string; optional):
        Internal fallback prop used by the hook layer to render a degraded
        error-only UI with traceback details when startup or layout injection
        fails.

    - style (:class:`~dash_ai_analyst.ChatStyle`; optional):
        Visual and text customizations.  See :class:`~dash_ai_analyst.ChatStyle`
        for all available options.

    - connector (:class:`~dash_ai_analyst.Connector`; optional):
        Authentication backend connector.  Pass a
        :class:`~dash_ai_analyst.PlotlyCloudConnector` or
        :class:`~dash_ai_analyst.DashEnterpriseConnector` instance with
        developer credentials to authenticate viewers automatically — no
        sign-in screen is shown.  When omitted, viewers sign in with their
        own Plotly Cloud accounts.
        **Never serialized to the browser** — stored server-side only.

    """

    _namespace = "dash_ai_analyst"
    _type = "AiAnalyst"
    _js_dist = [{"relative_package_path": "dash_ai_analyst.min.js", "namespace": "dash_ai_analyst"}]
    _css_dist = [{"relative_package_path": "dash_ai_analyst.css", "namespace": "dash_ai_analyst"}]

    @_explicitize_args
    def __init__(
        self,
        id=Component.UNDEFINED,
        inline=Component.UNDEFINED,
        show_fullscreen_toggle=Component.UNDEFINED,
        show_pdf_export=Component.UNDEFINED,
        skip_global_data=Component.UNDEFINED,
        system_prompt=Component.UNDEFINED,
        system_prompt_appendix=Component.UNDEFINED,
        error_traceback=Component.UNDEFINED,
        style=None,
        connector=Component.UNDEFINED,
        **kwargs,
    ):
        _has_error = error_traceback is not Component.UNDEFINED and error_traceback is not None

        # title/button_label/placeholder/welcome_message/theme are React props
        # populated from `style`; they are never set directly by the caller.
        # Store the connector server-side.  It is intentionally excluded from
        # _prop_names so it is never serialized to the browser.
        if not _has_error and connector is not Component.UNDEFINED and connector is not None:
            from ._connector import set_connector
            set_connector(connector)

        self._prop_names = [
            "id", "inline", "show_fullscreen_toggle", "show_pdf_export", "skip_global_data",
            "system_prompt", "system_prompt_appendix", "error_traceback",
            "title", "button_label", "button_tooltip", "placeholder", "welcome_message", "theme",
        ]
        self._type = "AiAnalyst"
        self._namespace = "dash_ai_analyst"
        self._valid_wildcard_attributes = []
        self.available_properties = [
            "id", "inline", "show_fullscreen_toggle", "show_pdf_export", "skip_global_data",
            "system_prompt", "system_prompt_appendix", "error_traceback",
            "title", "button_label", "button_tooltip", "placeholder", "welcome_message", "theme",
        ]
        self.available_wildcard_properties = []

        _explicit_args = kwargs.pop("_explicit_args")
        _locals = locals()
        _locals.update(kwargs)
        # Exclude `style` — it's not a React prop; its contents are unpacked below.
        args = {k: _locals[k] for k in _explicit_args if k not in ("connector", "style")}

        if "id" not in args:
            args["id"] = "_dash-ai-analyst-container"
        if "inline" not in args:
            args["inline"] = True
        if "show_fullscreen_toggle" not in args:
            args["show_fullscreen_toggle"] = True
        if "show_pdf_export" not in args:
            args["show_pdf_export"] = True
        if "skip_global_data" not in args:
            args["skip_global_data"] = False
        if "system_prompt" not in args:
            args["system_prompt"] = None
        if "system_prompt_appendix" not in args:
            args["system_prompt_appendix"] = None
        if "error_traceback" not in args:
            args["error_traceback"] = None

        s = style if style is not None else ChatStyle()
        args["title"] = s.title
        args["button_label"] = s.button_label
        args["button_tooltip"] = s.button_tooltip
        args["placeholder"] = s.placeholder
        args["welcome_message"] = s.welcome_message
        args["theme"] = s._theme_dict()

        super().__init__(**args)
