"""ChatStyle — whitelabeling configuration for the AiAnalyst component."""

from typing import Optional


class ChatStyle:
    """Styling and labeling options for the :class:`~dash_ai_analyst.AiAnalyst` chat UI.

    Pass an instance to ``AiAnalyst(style=...)`` to customize text labels and
    the visual theme without touching the rest of the component configuration.

    Example::

        from dash_ai_analyst import AiAnalyst, ChatStyle

        AiAnalyst(
            style=ChatStyle(
                title="Acme Data Assistant",
                button_label="Ask AI",
                placeholder="What would you like to know?",
                welcome_message=(
                    "Hi! I can answer questions about your sales and inventory data.\\n\\n"
                    "Try asking:\\n"
                    "- *Show me top products by revenue*\\n"
                    "- *How did Q1 compare to Q2?*"
                ),
                primary_color="#0057b8",
                logo_src="https://example.com/logo.png",
                border_radius="8px",
            )
        )

    All parameters are optional — omit any to keep the default.
    """

    def __init__(
        self,
        title: str = "Plotly Studio",
        button_label: str = "Ask AI",
        button_tooltip: str = "Ask questions this dashboard doesn't answer",
        placeholder: str = "Ask about the data and create new charts",
        # The home view opens with "What would you like to explore today?", so
        # there is no empty transcript for a greeting to fill by default.
        welcome_message: Optional[str] = None,
        primary_color: Optional[str] = None,
        secondary_color: Optional[str] = None,
        logo_src: Optional[str] = None,
        border_radius: Optional[str] = None,
        font_family: Optional[str] = None,
    ) -> None:
        self.title = title
        self.button_label = button_label
        self.button_tooltip = button_tooltip
        self.placeholder = placeholder
        self.welcome_message = welcome_message
        self.primary_color = primary_color
        self.secondary_color = secondary_color
        self.logo_src = logo_src
        self.border_radius = border_radius
        self.font_family = font_family

    def _theme_dict(self) -> dict:
        """Return the ``theme`` dict expected by the React component."""
        return {
            k: v
            for k, v in {
                "primary_color": self.primary_color,
                "secondary_color": self.secondary_color,
                "logo_src": self.logo_src,
                "border_radius": self.border_radius,
                "font_family": self.font_family,
            }.items()
            if v is not None
        }
